extends Node

func _ready() -> void:
	print("--- Test du SocialManager ---")
	
	# Test 1: Chat Local
	SocialManager.message_received.connect(func(sender, text, color):
		print("[Local Chat Test] %s: %s (Color: %s)" % [sender, text, str(color)])
	)
	SocialManager.send_chat("Bonjour tout le monde !")
	
	# Test 2: Réaction Locale
	SocialManager.reaction_received.connect(func(pid, emoji):
		print("[Local Reaction Test] Player %d sent: %s" % [pid, emoji])
	)
	SocialManager.send_reaction("🔥")
	
	# Test 3: Simulation Réseau (si NetworkManager est prêt)
	if NetworkManager:
		print("[Network Test] Simulating incoming RPC chat...")
		NetworkManager._client_receive_chat("Joueur Distant", "Salut !")
		
		print("[Network Test] Simulating incoming RPC reaction...")
		NetworkManager._client_receive_reaction(1, "😂")

	print("--- Fin des tests ---")
	get_tree().quit()
