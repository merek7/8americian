extends SceneTree
## Lanceur de tests headless (pas besoin de GUT pour le MVP).
## Usage: godot --headless --path game -s tests/test_runner.gd

var tests_run := 0
var tests_passed := 0
var failures: Array[String] = []


func _init() -> void:
    print("=== Tests démarrés ===")
    _test_card_factory()
    _test_deck_build()
    _test_legal_moves_basic()
    _test_fire_extinguisher_2spade()
    _test_fire_extinguisher_normal()
    _test_joker_always_legal()
    _test_score_table()
    _summary()
    quit(0 if failures.is_empty() else 1)


func _assert(cond: bool, label: String) -> void:
    tests_run += 1
    if cond:
        tests_passed += 1
        print("  ✓ %s" % label)
    else:
        failures.append(label)
        print("  ✗ %s" % label)


func _test_card_factory() -> void:
    print("[test_card_factory]")
    var c := Card.create(8, Card.Suit.SPADE)
    _assert(c.value == 8 and c.suit == Card.Suit.SPADE, "8♠ créé")
    _assert(c.points == 64, "8♠ vaut 64 pts")
    _assert(c.effect_type == Card.EffectType.BLOCK, "8♠ effet BLOCK")
    var j := Card.create(0, Card.Suit.NONE)
    _assert(j.points == 50, "Joker vaut 50 pts")
    _assert(j.is_joker(), "Joker is_joker()")


func _test_deck_build() -> void:
    print("[test_deck_build]")
    var d := Deck.new()
    d.build_standard(2)
    # 2 decks * (52 + 2 jokers) = 108
    _assert(d.size() == 108, "2 decks = 108 cartes (got %d)" % d.size())


func _test_legal_moves_basic() -> void:
    print("[test_legal_moves_basic]")
    var state := GameState.new()
    state.discard.push(Card.create(5, Card.Suit.HEART))
    var legal_same_suit := RuleValidator.is_legal_move(Card.create(9, Card.Suit.HEART), state)
    var legal_same_value := RuleValidator.is_legal_move(Card.create(5, Card.Suit.CLUB), state)
    var illegal := RuleValidator.is_legal_move(Card.create(9, Card.Suit.CLUB), state)
    _assert(legal_same_suit, "Même enseigne → légal")
    _assert(legal_same_value, "Même valeur → légal")
    _assert(not illegal, "Ni enseigne ni valeur → illégal")


func _test_fire_extinguisher_2spade() -> void:
    print("[test_fire_extinguisher_2spade]")
    var state := GameState.new()
    state.discard.push(Card.create(2, Card.Suit.SPADE))
    var fire := GameState.FireSanction.new()
    fire.source_card = Card.create(2, Card.Suit.SPADE)
    fire.damage_queue = [4, 2, 1]
    state.active_fire = fire

    _assert(RuleValidator.is_legal_move(Card.create(2, Card.Suit.SPADE), state), "2♠ éteint 2♠")
    _assert(not RuleValidator.is_legal_move(Card.create(2, Card.Suit.HEART), state), "2♥ N'éteint PAS 2♠")
    _assert(RuleValidator.is_legal_move(Card.create(8, Card.Suit.SPADE), state), "8♠ éteint 2♠")
    _assert(not RuleValidator.is_legal_move(Card.create(8, Card.Suit.HEART), state), "8♥ N'éteint PAS 2♠")
    _assert(RuleValidator.is_legal_move(Card.create(0, Card.Suit.NONE), state), "Joker éteint 2♠ (transfert)")


func _test_fire_extinguisher_normal() -> void:
    print("[test_fire_extinguisher_normal]")
    var state := GameState.new()
    var fire := GameState.FireSanction.new()
    fire.source_card = Card.create(2, Card.Suit.HEART)
    fire.damage_queue = [2, 1]
    state.active_fire = fire

    _assert(RuleValidator.is_legal_move(Card.create(2, Card.Suit.CLUB), state), "2♣ éteint 2♥")
    _assert(RuleValidator.is_legal_move(Card.create(8, Card.Suit.HEART), state), "8♥ éteint 2♥")
    _assert(not RuleValidator.is_legal_move(Card.create(5, Card.Suit.HEART), state), "5♥ N'éteint PAS le feu")


func _test_joker_always_legal() -> void:
    print("[test_joker_always_legal]")
    var state := GameState.new()
    state.discard.push(Card.create(5, Card.Suit.HEART))
    state.required_suit = Card.Suit.SPADE
    var joker := Card.create(0, Card.Suit.NONE)
    _assert(RuleValidator.is_legal_move(joker, state), "Joker légal même avec required_suit")


func _test_score_table() -> void:
    print("[test_score_table]")
    _assert(Card.create(1, Card.Suit.HEART).points == 1, "As = 1")
    _assert(Card.create(2, Card.Suit.SPADE).points == 4, "2♠ = 4")
    _assert(Card.create(8, Card.Suit.HEART).points == 32, "8 = 32")
    _assert(Card.create(8, Card.Suit.SPADE).points == 64, "8♠ = 64")
    _assert(Card.create(11, Card.Suit.SPADE).points == 22, "Valet♠ = 22")
    _assert(Card.create(11, Card.Suit.HEART).points == 11, "Valet = 11")
    _assert(Card.create(12, Card.Suit.HEART).points == 1, "Dame = 1")
    _assert(Card.create(13, Card.Suit.HEART).points == 1, "Roi = 1")


func _summary() -> void:
    print("\n=== Résumé : %d/%d tests passés ===" % [tests_passed, tests_run])
    for f in failures:
        print("  ✗ %s" % f)
