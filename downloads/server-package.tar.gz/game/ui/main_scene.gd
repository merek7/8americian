extends Control
## Scène principale. UI consomme les signals du GameManager. Aucune logique métier.

const CardViewScript = preload("res://ui/card_view.gd")
const SeatViewScript = preload("res://ui/seat_view.gd")

@onready var seats_layer: Control = $SeatsLayer
@onready var opponents_box: HBoxContainer = $OpponentsBox
@onready var player_seat_root: Control = $PlayerSeat
@onready var deck_pile: Control = $Center/DeckPile
@onready var discard_slot: Control = $Center/DiscardSlot
@onready var direction_coin: Control = $Center/DirectionCoin
@onready var deck_label: Label = $DeckLabel
@onready var status_label: Label = $TopBar/StatusLabel
@onready var turn_label: Label = $TurnBadge/TurnLabel
@onready var effect_badges: Control = $TopBar/EffectBadges
@onready var carte_button: Button = $Actions/CarteButton
@onready var draw_button: Button = $DrawButton
@onready var hamburger_button: Button = $TopBar/HamburgerButton
@onready var actions_menu: PopupMenu = $ActionsMenu
@onready var lobby_dialog: AcceptDialog = $LobbyDialog
@onready var lobby_name_input: LineEdit = $LobbyDialog/V/NameInput
@onready var lobby_host_button: Button = $LobbyDialog/V/HSplit/HostButton
@onready var lobby_join_button: Button = $LobbyDialog/V/HSplit/JoinButton
@onready var lobby_ip_input: LineEdit = $LobbyDialog/V/JoinFields/IPInput
@onready var lobby_port_input: LineEdit = $LobbyDialog/V/JoinFields/PortInput
@onready var lobby_password_input: LineEdit = $LobbyDialog/V/JoinFields/PasswordInput
@onready var lobby_list: RichTextLabel = $LobbyDialog/V/LobbyList
@onready var lobby_start_button: Button = $LobbyDialog/V/StartOnlineButton
@onready var lobby_leave_button: Button = $LobbyDialog/V/LeaveButton
@onready var suit_popup: AcceptDialog = $SuitChoicePopup
@onready var log_label: RichTextLabel = $LogPanel/Log
@onready var copy_log_button: Button = $LogPanel/CopyLogButton
@onready var log_toggle_button: Button = $LogToggle
@onready var log_panel: Panel = $LogPanel
@onready var ticker_label: Label = $Ticker
@onready var round_end_popup: ColorRect = $RoundEndPopup
@onready var round_end_subtitle: Label = $RoundEndPopup/Panel/VBox/Subtitle
@onready var round_end_scores: RichTextLabel = $RoundEndPopup/Panel/VBox/ScoresLabel
@onready var round_end_hourglass: Label = $RoundEndPopup/Panel/VBox/Hourglass
@onready var round_end_skip: Button = $RoundEndPopup/Panel/VBox/Actions/SkipButton
@onready var game_over_popup: ColorRect = $GameOverPopup
@onready var game_over_winner: Label = $GameOverPopup/Panel/VBox/Winner
@onready var game_over_replay: Button = $GameOverPopup/Panel/VBox/ReplayButton
@onready var chat_bar: Panel = $ChatBar
@onready var chat_input: LineEdit = $ChatBar/V/InputRow/ChatInput
@onready var chat_send_button: Button = $ChatBar/V/InputRow/SendButton
@onready var emoji_buttons: HBoxContainer = $ChatBar/V/EmojiBar
@onready var connection_toast: VBoxContainer = $ConnectionToast
@onready var countdown_overlay: ColorRect = $CountdownOverlay
@onready var countdown_label: Label = $CountdownOverlay/CountdownLabel
@onready var pause_popup: ColorRect = $PausePopup
@onready var pause_reason: Label = $PausePopup/Panel/VBox/Reason
@onready var pause_quit_button: Button = $PausePopup/Panel/VBox/PauseQuit

var _previous_lobby_peers: Dictionary = {}

var _round_timer_left: float = 0.0
var _round_timer_active: bool = false
@onready var carte_bubble: Label = $CarteBubble

var calling_carte_next_turn: bool = false
var pending_card_for_suit: Card = null
var seat_views: Dictionary = {}  # player_id -> SeatView


func _ready() -> void:
    GameManager.game_started.connect(_on_game_started)
    GameManager.player_changed.connect(_on_player_changed)
    GameManager.card_played.connect(_on_card_played)
    GameManager.card_drawn.connect(_on_card_drawn)
    GameManager.effect_triggered.connect(_on_effect_triggered)
    GameManager.illegal_move.connect(_on_illegal_move)
    GameManager.round_ended.connect(_on_round_ended)
    GameManager.game_over.connect(_on_game_over)
    GameManager.fire_landed.connect(_on_fire_landed)

    draw_button.pressed.connect(_on_draw_pressed)
    carte_button.pressed.connect(_on_carte_pressed)
    copy_log_button.pressed.connect(_on_copy_log_pressed)
    round_end_skip.pressed.connect(_on_continue_round)
    game_over_replay.pressed.connect(_on_replay_pressed)
    set_process(true)

    hamburger_button.pressed.connect(_on_hamburger)
    log_toggle_button.pressed.connect(_toggle_log_panel)
    actions_menu.id_pressed.connect(_on_action_menu_id)

    lobby_host_button.pressed.connect(_on_host_pressed)
    lobby_join_button.pressed.connect(_on_join_pressed)
    lobby_start_button.pressed.connect(_on_start_online_pressed)
    lobby_leave_button.pressed.connect(_on_leave_online_pressed)
    NetworkManager.lobby_updated.connect(_on_lobby_updated)
    NetworkManager.connected_to_host.connect(_on_connected_to_host)
    NetworkManager.connection_failed.connect(_on_connection_failed)
    NetworkManager.state_received.connect(_on_state_received)
    NetworkManager.log_message.connect(func(m): _log("[color=#88ccff]🌐 %s[/color]" % m))
    NetworkManager.remote_event.connect(_on_remote_event)
    NetworkManager.pings_updated.connect(_on_pings_updated)
    NetworkManager.player_disconnected_mid_game.connect(_on_player_disconnected_mid_game)
    pause_quit_button.pressed.connect(_on_menu_pressed)
    lobby_name_input.text = Profile.pseudo

    deck_pile.draw.connect(_draw_deck_pile)
    deck_pile.resized.connect(deck_pile.queue_redraw)
    discard_slot.draw.connect(_draw_discard_frame)
    discard_slot.resized.connect(discard_slot.queue_redraw)

    get_viewport().size_changed.connect(_on_viewport_resized)

    SocialManager.message_received.connect(_on_social_message)
    SocialManager.reaction_received.connect(_on_social_reaction)

    # Chat send
    chat_send_button.pressed.connect(_on_chat_send)
    chat_input.text_submitted.connect(func(_t): _on_chat_send())
    var emojis := ["👍", "❤", "😂", "😮", "🔥", "👏"]
    var idx_e: int = 0
    for btn in emoji_buttons.get_children():
        if btn is Button:
            var emoji_str: String = emojis[idx_e]
            btn.pressed.connect(func(): SocialManager.send_reaction(emoji_str))
            idx_e += 1

    _maybe_start_dedicated_server()
    _maybe_apply_pending_launch()


func _on_viewport_resized() -> void:
    if GameManager.state == null: return
    _build_seats()
    _refresh_all()


func _on_menu_pressed() -> void:
    SoundFX.play(&"click")
    if NetworkManager.is_online:
        NetworkManager.leave()
    if has_node("/root/Tournament"):
        Tournament.reset()
    GameManager.state = null
    get_tree().change_scene_to_file("res://ui/main_menu.tscn")


func _maybe_apply_pending_launch() -> void:
    var data: Dictionary = GameSession.pending_launch
    GameSession.pending_launch = {}
    if data.is_empty(): return
    var mode: String = data.get("mode", "")
    if mode == "online":
        lobby_dialog.popup_centered()
        return
    if mode == "solo_vs_ai" or mode == "local_multi" or mode == "tournament":
        _start_game_with(
            mode,
            data.get("nb_players", 2),
            data.get("score_target", 50),
            data.get("cards_dealt", 5)
        )


# ─── Mode serveur dédié ────────────────────────────────────────────────────────

func _maybe_start_dedicated_server() -> void:
    var args := OS.get_cmdline_user_args()
    var is_server := false
    var port := NetworkManager.DEFAULT_PORT
    var start_on := 2
    var score: int = 50
    var password := ""
    for arg in args:
        if arg == "--server": is_server = true
        elif arg.begins_with("--port="): port = int(arg.substr(7))
        elif arg.begins_with("--start-on="): start_on = int(arg.substr(11))
        elif arg.begins_with("--score="): score = int(arg.substr(8))
        elif arg.begins_with("--password="): password = arg.substr(11)
    if not is_server: return

    print("[Server] Mode dédié — port=%d start-on=%d score=%d password=%s" % [port, start_on, score, "(défini)" if password != "" else "(aucun)"])
    visible = false  # plus d'UI
    if not NetworkManager.start_dedicated_server(port, password):
        print("[Server] Échec démarrage")
        get_tree().quit(1)
        return
    NetworkManager.lobby_updated.connect(func(players):
        print("[Server] Lobby : %d joueur(s)" % players.size())
        if players.size() >= start_on and (GameManager.state == null or GameManager.state.game_finished):
            NetworkManager.request_start_game(score)
    )
    GameManager.game_over.connect(func(winner):
        print("[Server] Partie terminée, gagnant: %d" % winner)
    )


func _start_game_with(mode_str: String, nb_players: int, score_target: int, cards_dealt: int) -> void:
    var ai_diff: String = Profile.ai_difficulty if has_node("/root/Profile") else "basic"
    if mode_str == "tournament" and has_node("/root/Tournament"):
        var tcfg: Dictionary = Tournament.next_game_config()
        if not tcfg.is_empty():
            ai_diff = tcfg.get("ai_difficulty", ai_diff)
    var config := {
        "nb_decks": maxi(2, int(ceil(nb_players / 2.0))),
        "nb_players": nb_players,
        "cards_dealt": cards_dealt,
        "score_target": score_target,
        "mode": mode_str,
        "ai_difficulty": ai_diff
    }
    var names: Array = []
    if mode_str == "tournament" and has_node("/root/Tournament"):
        names.append(Profile.pseudo)
        for n in Tournament.ai_names():
            names.append(n)
        var per_ai: Array = []
        for i in nb_players - 1:
            per_ai.append(Tournament.ai_difficulty_for_seat(i))
        config["per_ai_difficulty"] = per_ai
        # padding au cas où
        while names.size() < nb_players:
            names.append("IA %d" % names.size())
    else:
        for i in nb_players:
            if mode_str == "solo_vs_ai" and i > 0:
                names.append("IA %d" % i)
            elif mode_str == "solo_vs_ai" and i == 0:
                names.append(Profile.pseudo)
            elif i == 0:
                names.append(Profile.pseudo)
            else:
                names.append("Joueur %d" % (i + 1))
    GameManager.start_game(config, names)


func _on_replay_pressed() -> void:
    # Tournoi en cours : lancer la manche suivante
    if has_node("/root/Tournament") and Tournament.active:
        var tcfg: Dictionary = Tournament.next_game_config()
        if not tcfg.is_empty():
            game_over_popup.visible = false
            _start_game_with("tournament", tcfg.get("nb_players", 2),
                             tcfg.get("score_target", 50), tcfg.get("cards_dealt", 5))
            return
    # Tournoi terminé : retour au menu
    if has_node("/root/Tournament") and not Tournament.active and Tournament.total_games > 0:
        Tournament.reset()
        _on_menu_pressed()
        return
    # Sinon : replay normal
    if GameManager.config and not GameManager.config.is_empty():
        var c: Dictionary = GameManager.config
        _start_game_with(c.get("mode", "local_multi"), c.get("nb_players", 2),
                         c.get("score_target", 50), c.get("cards_dealt", 5))


func _on_hamburger() -> void:
    SoundFX.play(&"click")
    var btn_pos := hamburger_button.global_position
    actions_menu.position = Vector2i(btn_pos + Vector2(0, hamburger_button.size.y + 4))
    actions_menu.popup()


func _on_action_menu_id(id: int) -> void:
    SoundFX.play(&"click")
    match id:
        0: _on_replay_pressed()
        1: lobby_dialog.popup_centered()
        2: _on_menu_pressed()
        3: get_tree().quit()
        4: _toggle_log_panel()


func _on_game_started(_cfg: Dictionary) -> void:
    _build_seats()
    _log("[b]Partie démarrée[/b] — %d joueurs" % GameManager.state.players.size())
    game_over_popup.visible = false
    round_end_popup.visible = false
    _refresh_all()
    _play_ready_go_countdown()


func _play_ready_go_countdown() -> void:
    countdown_overlay.visible = true
    countdown_overlay.modulate.a = 1.0
    var steps: Array[Dictionary] = [
        {"txt": "3", "col": Color(1, 0.95, 0.55), "snd": &"countdown"},
        {"txt": "2", "col": Color(1, 0.78, 0.30), "snd": &"countdown"},
        {"txt": "1", "col": Color(1, 0.45, 0.30), "snd": &"countdown"},
        {"txt": "GO !", "col": Color(0.45, 1.0, 0.55), "snd": &"go"},
    ]
    var tw := create_tween()
    for s in steps:
        var step: Dictionary = s
        var step_text: String = step["txt"]
        var step_color: Color = step["col"]
        var step_snd: StringName = step["snd"]
        tw.tween_callback(func():
            countdown_label.text = step_text
            countdown_label.add_theme_color_override("font_color", step_color)
            countdown_label.modulate = Color(1, 1, 1, 0)
            countdown_label.scale = Vector2(0.6, 0.6)
            countdown_label.pivot_offset = countdown_label.size / 2.0
            SoundFX.play(step_snd)
            var t2 := create_tween().set_parallel(true)
            t2.tween_property(countdown_label, "modulate:a", 1.0, 0.18)
            t2.tween_property(countdown_label, "scale", Vector2(1.2, 1.2), 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
            t2.chain().tween_property(countdown_label, "scale", Vector2(1.0, 1.0), 0.15)
        )
        tw.tween_interval(0.7)
    tw.tween_callback(func():
        var fade := create_tween()
        fade.tween_property(countdown_overlay, "modulate:a", 0.0, 0.35)
        fade.tween_callback(func():
            countdown_overlay.visible = false
            _animate_deal()
        )
    )


func _animate_deal() -> void:
    if GameManager.state == null: return
    var n: int = GameManager.config.get("cards_dealt", 5)
    for round_idx in n:
        for p in GameManager.state.players:
            var seat: SeatView = seat_views.get(p.id)
            if seat == null: continue
            var ghost := Control.new()
            ghost.set_script(CardViewScript)
            add_child(ghost)
            ghost.setup(null, true)
            ghost.size = CardView.CARD_SIZE
            var from_pos: Vector2 = deck_pile.global_position + (deck_pile.size - ghost.size) / 2.0
            var to_pos: Vector2 = seat.global_position + Vector2(seat.size.x / 2.0, seat.size.y / 2.0) - ghost.size / 2.0
            ghost.global_position = from_pos
            ghost.modulate.a = 1.0
            var tw := create_tween().set_parallel(true)
            tw.tween_interval((round_idx * GameManager.state.players.size() + p.id) * 0.06)
            tw.chain().tween_property(ghost, "global_position", to_pos, 0.28).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
            tw.tween_property(ghost, "rotation", randf_range(-0.12, 0.12), 0.28)
            tw.chain().tween_property(ghost, "modulate:a", 0.0, 0.10)
            tw.chain().tween_callback(ghost.queue_free)


func _build_seats() -> void:
    for child in seats_layer.get_children():
        seats_layer.remove_child(child)
        child.queue_free()
    for child in player_seat_root.get_children():
        player_seat_root.remove_child(child)
        child.queue_free()
    seat_views.clear()

    var state := GameManager.state
    var human_id := _local_human_player_id()
    var n: int = state.players.size()

    var viewport_size := get_viewport_rect().size
    var center := viewport_size / 2.0
    # Ellipse autour de la table : a = horizontal, b = vertical
    var ellipse_a: float = max(360.0, viewport_size.x * 0.42)
    var ellipse_b: float = max(220.0, viewport_size.y * 0.36)

    var local_ordinal: int = 0
    for i in n:
        if state.players[i].id == human_id:
            local_ordinal = i; break

    for i in n:
        var p: Player = state.players[i]
        var seat := Control.new()
        seat.set_script(SeatViewScript)
        seat.is_self = (p.id == human_id)
        seat.seat_size = Vector2(820, 200) if seat.is_self else Vector2(260, 200)
        # Couleur unique par siège
        if seat.is_self and has_node("/root/Profile"):
            seat.seat_color = Profile.avatar_color()
        else:
            seat.seat_color = SeatView.SEAT_PALETTE[p.id % SeatView.SEAT_PALETTE.size()]

        if seat.is_self:
            seat.size = seat.seat_size
            player_seat_root.add_child(seat)
            seat.anchor_right = 1.0
            seat.anchor_bottom = 1.0
            seat.offset_left = 0
            seat.offset_top = 0
            seat.offset_right = 0
            seat.offset_bottom = 0
        else:
            # Place autour de l'ellipse, en partant du bas (joueur local) et tournant horaire
            var rel: int = ((i - local_ordinal) + n) % n  # 0 = local, 1..N-1 = opposants
            var angle: float = PI / 2.0 + (TAU * float(rel) / float(n))  # PI/2 = bas
            var pos := center + Vector2(cos(angle) * ellipse_a, sin(angle) * ellipse_b)
            # Pousse les sièges du haut un peu plus haut (sortie d'écran évitée)
            if pos.y < center.y:
                pos.y -= 30
            seat.size = seat.seat_size
            seat.position = pos - seat.size / 2.0
            seats_layer.add_child(seat)

        seat_views[p.id] = seat
        seat.set_player(p)


func _on_player_changed(_pid: int) -> void:
    if GameManager.config.get("mode", "") == "local_multi":
        _build_seats()
        _camera_pan_to_self()
    _refresh_all()


func _camera_pan_to_self() -> void:
    # Effet "caméra" : zoom-in léger sur le siège local + flash sur statut
    if seats_layer == null: return
    seats_layer.pivot_offset = seats_layer.size / 2.0
    seats_layer.scale = Vector2(0.96, 0.96)
    var tw := create_tween()
    tw.tween_property(seats_layer, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)

    if status_label:
        var orig_mod := status_label.modulate
        status_label.modulate = Color(1, 0.9, 0.4, 1)
        var tw2 := create_tween()
        tw2.tween_property(status_label, "modulate", orig_mod, 0.6)


func _on_card_played(card: Card, pid: int) -> void:
    var p: Player = GameManager.state.players[pid]
    _log("[color=#cfe7d6]%s[/color] joue [b]%s[/b]" % [p.name, card.to_string_short()])
    SoundFX.play(&"card_play")
    if p.hand_size() == 1 and p.has_called_carte:
        _show_carte_bubble("📢 %s : CARTE !" % p.name)
        SoundFX.play(&"carte")
    _animate_play_to_discard(pid, card)


func _on_card_drawn(pid: int, count: int) -> void:
    var p: Player = GameManager.state.players[pid]
    _log("[color=#a8b9d0]%s pioche %d carte(s)[/color]" % [p.name, count])
    SoundFX.play(&"card_draw")
    _animate_draw_to_seat(pid, count)
    _refresh_all()


func _on_effect_triggered(effect_name: String, payload: Dictionary) -> void:
    if effect_name != "NONE":
        _log("[color=#ffb845]⚡ %s[/color] %s" % [effect_name, payload.get("message", "")])
    if effect_badges:
        match effect_name:
            "REVERSE": effect_badges.flash("reverse", 1500)
            "SKIP": effect_badges.flash("skip", 1500)
            "FIRE": effect_badges.flash("fire", 800)
            "BLOCK": effect_badges.flash("block", 800)
            "TRANSFER": effect_badges.flash("transfer", 1200)
            "REPLAY": effect_badges.flash("replay", 800)


func _on_illegal_move(_pid: int, reason: String) -> void:
    _log("[color=#ff6b6b]⛔ %s[/color]" % reason)
    SoundFX.play(&"bad")


func _on_fire_landed(pid: int, dmg: int) -> void:
    var p: Player = GameManager.state.players[pid]
    _log("[color=#ff8c4a]🔥 %s encaisse %d cartes[/color]" % [p.name, dmg])
    SoundFX.play(&"fire")
    _pulse_seat(pid, Color(1, 0.3, 0.2))
    var seat: SeatView = seat_views.get(pid)
    if seat:
        seat.play_fire_burst()
        seat.play_fire_flicker(1.6)


func _on_round_ended(scores: Dictionary) -> void:
    var msg := "Manche terminée — "
    for pid in scores:
        var p: Player = GameManager.state.players[pid]
        msg += "%s=%d  " % [p.name, scores[pid]]
    _log("[color=cyan]%s[/color]" % msg)
    if not GameManager.state.game_finished:
        _show_round_end_popup(scores)


func _on_game_over(winner: int) -> void:
    var p: Player = GameManager.state.players[winner]
    _log("[color=lime][b]🏆 Gagnant : %s[/b][/color]" % p.name)
    var human_won: bool = (has_node("/root/Profile") and p.name == Profile.pseudo)
    if has_node("/root/Profile"):
        var diff_for_stats: String = GameManager.config.get("ai_difficulty", "basic")
        var local_p: Player = GameManager.state.players[_local_human_player_id()]
        var end_score: int = local_p.score if human_won else -1
        var is_online: bool = NetworkManager.is_online if has_node("/root/NetworkManager") else false
        Profile.record_game_detailed(human_won, diff_for_stats, end_score, is_online)
    round_end_popup.visible = false
    _round_timer_active = false

    # Tournament flow
    if has_node("/root/Tournament") and Tournament.active:
        Tournament.record_game_winner(p.name)
        if Tournament.active:
            # Tournoi continue : afficher progression + bouton "Manche suivante"
            game_over_winner.text = "%s gagne la manche !\n%s" % [p.name, Tournament.progress_text()]
            game_over_replay.text = "Manche suivante"
        else:
            # Tournoi terminé : champion screen
            var leader_wins: int = int(Tournament.wins.get(p.name, 0))
            game_over_winner.text = "🏆 %s\nremporte le tournoi (%d / %d)" % [p.name, leader_wins, Tournament.total_games]
            game_over_replay.text = "Retour au menu"
    else:
        game_over_winner.text = "%s remporte la partie !" % p.name
        game_over_replay.text = "Nouvelle partie"

    game_over_popup.modulate = Color(1, 1, 1, 0)
    game_over_popup.visible = true
    SoundFX.play(&"win")
    create_tween().tween_property(game_over_popup, "modulate:a", 1.0, 0.4)
    _spawn_confetti()


func _spawn_confetti() -> void:
    var colors: Array[Color] = [
        Color(1, 0.8, 0.2), Color(0.95, 0.3, 0.4), Color(0.4, 0.85, 1),
        Color(0.5, 1, 0.5), Color(1, 0.5, 0.85)
    ]
    var rng := RandomNumberGenerator.new()
    rng.randomize()
    for i in 80:
        var p := ColorRect.new()
        p.color = colors[i % colors.size()]
        p.size = Vector2(rng.randf_range(6, 14), rng.randf_range(8, 18))
        p.position = Vector2(rng.randf_range(0, size.x), -20)
        p.rotation = rng.randf_range(0, TAU)
        add_child(p)
        var fall_t: float = rng.randf_range(1.6, 2.6)
        var x_drift: float = rng.randf_range(-80, 80)
        var tw := create_tween().set_parallel(true)
        tw.tween_property(p, "position:y", size.y + 30, fall_t).set_trans(Tween.TRANS_CUBIC)
        tw.tween_property(p, "position:x", p.position.x + x_drift, fall_t)
        tw.tween_property(p, "rotation", p.rotation + rng.randf_range(-PI * 4, PI * 4), fall_t)
        tw.chain().tween_property(p, "modulate:a", 0.0, 0.4)
        tw.chain().tween_callback(p.queue_free)


func _show_round_end_popup(scores: Dictionary) -> void:
    var st := GameManager.state
    var winner_id: int = -1
    var min_score := -1
    for pid in scores:
        var s: int = scores[pid]
        var p: Player = st.players[pid]
        if not p.is_eliminated and (min_score == -1 or s < min_score):
            min_score = s; winner_id = pid

    var winner_name: String = st.players[winner_id].name if winner_id >= 0 else "—"
    round_end_subtitle.text = "%s remporte la manche" % winner_name

    var bb := ""
    for p in st.players:
        var pts: int = scores.get(p.id, p.score)
        var prefix := "🏆 " if p.id == winner_id else "•  "
        var col := "#5fff8c" if p.id == winner_id else ("#ff7777" if p.is_eliminated else "#cfe7d6")
        var elim := "  [color=#ff5555](éliminé)[/color]" if p.is_eliminated else ""
        bb += "[color=%s]%s%s — %d pts%s[/color]\n" % [col, prefix, p.name, pts, elim]
    round_end_scores.text = bb

    round_end_popup.modulate = Color(1, 1, 1, 0)
    round_end_popup.visible = true
    create_tween().tween_property(round_end_popup, "modulate:a", 1.0, 0.3)
    _round_timer_left = 10.0
    _round_timer_active = true
    round_end_hourglass.text = "⏳  10"


func _process(delta: float) -> void:
    if not _round_timer_active: return
    _round_timer_left -= delta
    var left_int: int = int(ceil(_round_timer_left))
    round_end_hourglass.text = "⏳  %d" % max(0, left_int)
    if _round_timer_left <= 0.0:
        _on_continue_round()


func _on_continue_round() -> void:
    _round_timer_active = false
    var tw := create_tween()
    tw.tween_property(round_end_popup, "modulate:a", 0.0, 0.25)
    tw.tween_callback(func(): round_end_popup.visible = false)
    GameManager.continue_to_next_round()


# ─── Rendu ─────────────────────────────────────────────────────────────────────

func _refresh_all() -> void:
    if GameManager.state == null:
        return
    _refresh_seats()
    _refresh_center()
    _refresh_hud()


func _refresh_seats() -> void:
    var state := GameManager.state
    var local_id := _local_human_player_id()
    var fire_target_pid: int = state.current_player_idx if state.active_fire != null else -1
    var block_target_pid: int = state.current_player_idx if (state.required_suit >= 0 and state.active_fire == null) else -1
    for p in state.players:
        var seat: SeatView = seat_views.get(p.id)
        if seat == null: continue
        seat.set_player(p)  # ← critique : maj la référence (recréée à chaque push)
        # État de siège (fire prioritaire sur block)
        if p.id == fire_target_pid:
            seat.set_seat_state("fire")
        elif p.id == block_target_pid:
            seat.set_seat_state("block")
        else:
            seat.set_seat_state("normal")
        seat.set_active(p.id == state.current_player_idx)
        if p.id == local_id:
            seat.refresh_hand(
                func(c: Card) -> bool: return RuleValidator.is_legal_move(c, state),
                _on_card_clicked
            )
        else:
            seat.refresh_hand()


func _local_human_player_id() -> int:
    if NetworkManager.is_online and not NetworkManager.is_host:
        return NetworkManager.local_player_id
    if NetworkManager.is_online and NetworkManager.is_host:
        return 0
    # En multi local hot-seat : le joueur courant est "self" (sa main est révélée)
    if GameManager.config.get("mode", "") == "local_multi" and GameManager.state:
        return GameManager.state.current_player_idx
    return 0


func _refresh_center() -> void:
    var top := GameManager.state.discard.top_reference()
    for child in discard_slot.get_children():
        discard_slot.remove_child(child)
        child.queue_free()
    if top != null:
        var cv := Control.new()
        cv.set_script(CardViewScript)
        cv.size = CardView.CARD_SIZE
        cv.position = (discard_slot.size - cv.size) / 2.0
        discard_slot.add_child(cv)
        cv.setup(top, false)
        cv.set_playable(false)
    deck_label.visible = false
    deck_pile.queue_redraw()
    discard_slot.queue_redraw()
    if direction_coin: direction_coin.set_direction(GameManager.state.direction)


func _draw_deck_pile() -> void:
    if GameManager.state == null: return
    var sz := deck_pile.size
    var card_sz: Vector2 = CardView.CARD_SIZE
    var center := (sz - card_sz) / 2.0
    var deck_size: int = GameManager.state.deck.size()
    var stack_count: int = clampi(floori(deck_size / 15.0), 1, 4)
    # Plaque arrière (slot)
    var slot_rect := Rect2(Vector2(-6, -6), sz + Vector2(12, 12))
    _rounded_fill(deck_pile, slot_rect, 14.0, Color(0.04, 0.10, 0.07, 0.85))
    _rounded_border(deck_pile, slot_rect, 14.0, Color(1.0, 0.92, 0.45, 0.30), 1.5)
    # Stack de cartes
    for i in stack_count:
        var off := Vector2(i * 1.5, -i * 2.0)
        _draw_pile_card(deck_pile, Rect2(center + off, card_sz))
    # Label "PIOCHE"
    var f := ThemeDB.fallback_font
    var lbl := "PIOCHE"
    var ts := f.get_string_size(lbl, HORIZONTAL_ALIGNMENT_CENTER, -1, 11)
    deck_pile.draw_string(f, Vector2(sz.x / 2.0 - ts.x / 2.0, -10), lbl,
                          HORIZONTAL_ALIGNMENT_CENTER, -1, 11, Color(1, 0.92, 0.45, 0.85))
    # Chip count
    var count_lbl := str(deck_size)
    var cs := f.get_string_size(count_lbl, HORIZONTAL_ALIGNMENT_CENTER, -1, 14)
    var chip_pos := Vector2(sz.x - 12, sz.y - 12)
    deck_pile.draw_circle(chip_pos, 16, Color(0.10, 0.40, 0.22, 0.95))
    deck_pile.draw_arc(chip_pos, 16, 0, TAU, 32, Color(1, 0.92, 0.45, 0.95), 1.8, true)
    deck_pile.draw_string(f, chip_pos - cs / 2.0 + Vector2(0, cs.y / 4.0), count_lbl,
                          HORIZONTAL_ALIGNMENT_CENTER, -1, 14, Color(1, 0.95, 0.7, 1))


func _draw_discard_frame() -> void:
    var sz := discard_slot.size
    var slot_rect := Rect2(Vector2(-6, -6), sz + Vector2(12, 12))
    _rounded_fill(discard_slot, slot_rect, 14.0, Color(0.04, 0.10, 0.07, 0.85))
    _rounded_border(discard_slot, slot_rect, 14.0, Color(1.0, 0.92, 0.45, 0.30), 1.5)
    var f := ThemeDB.fallback_font
    var lbl := "DÉFAUSSE"
    var ts := f.get_string_size(lbl, HORIZONTAL_ALIGNMENT_CENTER, -1, 11)
    discard_slot.draw_string(f, Vector2(sz.x / 2.0 - ts.x / 2.0, -10), lbl,
                              HORIZONTAL_ALIGNMENT_CENTER, -1, 11, Color(1, 0.92, 0.45, 0.85))


func _draw_pile_card(c: Control, rect: Rect2) -> void:
    var radius: float = 8.0
    # Ombre
    var shadow := Rect2(rect.position + Vector2(2, 4), rect.size)
    _rounded_fill(c, shadow, radius, Color(0, 0, 0, 0.35))
    # Fond bleu
    _rounded_fill(c, rect, radius, Color(0.13, 0.18, 0.45))
    # Motif
    var step := 8.0
    var t: float = -rect.size.y
    while t < rect.size.x + rect.size.y:
        c.draw_line(rect.position + Vector2(t, 0), rect.position + Vector2(t + rect.size.y, rect.size.y),
                    Color(0.20, 0.28, 0.55, 0.6), 1.0)
        c.draw_line(rect.position + Vector2(t + rect.size.y, 0), rect.position + Vector2(t, rect.size.y),
                    Color(0.20, 0.28, 0.55, 0.6), 1.0)
        t += step
    # Bordure
    _rounded_border(c, rect, radius, Color(0.4, 0.5, 0.85, 0.6), 1.5)


func _rounded_fill(c: Control, rect: Rect2, r: float, color: Color) -> void:
    c.draw_colored_polygon(_round_corners(rect, r, 6), color)


func _rounded_border(c: Control, rect: Rect2, r: float, color: Color, w: float) -> void:
    var pts := _round_corners(rect, r, 6)
    pts.append(pts[0])
    c.draw_polyline(pts, color, w, true)


func _round_corners(rect: Rect2, r: float, steps: int) -> PackedVector2Array:
    var p := PackedVector2Array()
    var corners := [
        Vector2(rect.position.x + r, rect.position.y + r),
        Vector2(rect.position.x + rect.size.x - r, rect.position.y + r),
        Vector2(rect.position.x + rect.size.x - r, rect.position.y + rect.size.y - r),
        Vector2(rect.position.x + r, rect.position.y + rect.size.y - r),
    ]
    var starts := [PI, -PI / 2.0, 0.0, PI / 2.0]
    for i in 4:
        for s in steps + 1:
            var t: float = starts[i] + (PI / 2.0) * (float(s) / float(steps))
            p.append(corners[i] + Vector2(cos(t), sin(t)) * r)
    return p


func _refresh_hud() -> void:
    var cur := GameManager.state.current_player()
    if turn_label: turn_label.text = "Tour : %s" % cur.name
    if effect_badges: effect_badges.set_state(GameManager.state)
    carte_button.disabled = cur.hand_size() != 2 or cur.is_ai


# ─── Animations ────────────────────────────────────────────────────────────────

func _animate_play_to_discard(pid: int, card: Card = null) -> void:
    var seat: SeatView = seat_views.get(pid)
    if seat == null or discard_slot == null: return
    var ghost := Control.new()
    ghost.set_script(CardViewScript)
    add_child(ghost)
    var to_show: Card = card if card != null else GameManager.state.discard.top_reference()
    ghost.setup(to_show, false)
    ghost.size = CardView.CARD_SIZE
    var from_pos := seat.global_position + Vector2(seat.size.x / 2.0, seat.size.y / 2.0) - ghost.size / 2.0
    var to_pos := discard_slot.global_position + (discard_slot.size - ghost.size) / 2.0
    ghost.global_position = from_pos
    ghost.modulate.a = 0.0
    var tw := create_tween().set_parallel(true)
    tw.tween_property(ghost, "modulate:a", 1.0, 0.08)
    tw.tween_property(ghost, "global_position", to_pos, 0.32).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
    tw.tween_property(ghost, "rotation", randf_range(-0.15, 0.15), 0.32)
    tw.chain().tween_callback(ghost.queue_free)


func _animate_draw_to_seat(pid: int, count: int) -> void:
    var seat: SeatView = seat_views.get(pid)
    if seat == null or deck_pile == null: return
    var n: int = mini(count, 3)  # plafond visuel
    for i in n:
        var ghost := Control.new()
        ghost.set_script(CardViewScript)
        add_child(ghost)
        ghost.setup(null, true)
        ghost.size = CardView.CARD_SIZE
        var from_pos := deck_pile.global_position + (deck_pile.size - ghost.size) / 2.0
        var to_pos := seat.global_position + Vector2(seat.size.x / 2.0, seat.size.y / 2.0) - ghost.size / 2.0
        ghost.global_position = from_pos
        ghost.modulate.a = 0.95
        var tw := create_tween().set_parallel(true)
        tw.tween_interval(i * 0.08)
        tw.chain().tween_property(ghost, "global_position", to_pos, 0.32).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
        tw.tween_property(ghost, "rotation", randf_range(-0.1, 0.1), 0.32)
        tw.chain().tween_property(ghost, "modulate:a", 0.0, 0.12)
        tw.chain().tween_callback(ghost.queue_free)


func _pulse_seat(pid: int, color: Color) -> void:
    var seat: SeatView = seat_views.get(pid)
    if seat == null: return
    var orig_mod := seat.modulate
    var tw := create_tween()
    tw.tween_property(seat, "modulate", Color(color.r, color.g, color.b, 1.0), 0.15)
    tw.tween_property(seat, "modulate", orig_mod, 0.45)


# ─── Actions joueur ────────────────────────────────────────────────────────────

func _on_card_clicked(card: Card) -> void:
    var cur := GameManager.state.current_player()
    var local_id := _local_human_player_id()

    # En ligne : seul le joueur dont c'est le tour ET qui est local peut jouer.
    if NetworkManager.is_online and cur.id != local_id:
        _log("[color=#9aa]Pas votre tour[/color]")
        return
    if cur.is_ai: return
    if not RuleValidator.is_legal_move(card, GameManager.state):
        _log("[color=#9aa]Carte %s non jouable[/color]" % card.to_string_short())
        return

    if card.value == 8:
        pending_card_for_suit = card
        suit_popup.popup_centered()
        return

    var ctx := {"calling_carte": calling_carte_next_turn}
    calling_carte_next_turn = false
    _submit_play(card, ctx)


func _submit_play(card: Card, ctx: Dictionary) -> void:
    if NetworkManager.is_online and not NetworkManager.is_host:
        NetworkManager.request_play_card.rpc_id(1, {"v": card.value, "s": card.suit}, ctx)
    else:
        GameManager.player_plays_card(GameManager.state.current_player().id, card, ctx)


func _on_draw_pressed() -> void:
    var cur := GameManager.state.current_player()
    var local_id := _local_human_player_id()
    if NetworkManager.is_online and cur.id != local_id: return
    if cur.is_ai: return
    if NetworkManager.is_online and not NetworkManager.is_host:
        NetworkManager.request_draw.rpc_id(1)
    else:
        GameManager.player_draws(cur.id)


func _on_carte_pressed() -> void:
    calling_carte_next_turn = true
    _log("📢 \"Carte\" annoncée pour le prochain coup")
    _show_carte_bubble("CARTE !")


func _on_suit_chosen(suit: int) -> void:
    if pending_card_for_suit == null: return
    var ctx := {"chosen_suit": suit, "calling_carte": calling_carte_next_turn}
    calling_carte_next_turn = false
    _submit_play(pending_card_for_suit, ctx)
    pending_card_for_suit = null
    suit_popup.hide()


func _show_carte_bubble(text: String) -> void:
    if carte_bubble == null: return
    carte_bubble.text = text
    carte_bubble.modulate = Color(1, 1, 1, 0)
    carte_bubble.scale = Vector2(0.5, 0.5)
    carte_bubble.pivot_offset = carte_bubble.size / 2.0
    carte_bubble.visible = true
    var tw := create_tween().set_parallel(true)
    tw.tween_property(carte_bubble, "modulate:a", 1.0, 0.18)
    tw.tween_property(carte_bubble, "scale", Vector2(1.2, 1.2), 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tw.chain().tween_property(carte_bubble, "scale", Vector2(1.0, 1.0), 0.15)
    tw.chain().tween_interval(0.9)
    tw.chain().tween_property(carte_bubble, "modulate:a", 0.0, 0.3)
    tw.chain().tween_callback(func(): carte_bubble.visible = false)


func _log(msg: String) -> void:
    log_label.append_text(msg + "\n")
    _show_ticker(msg)


func _show_ticker(msg: String) -> void:
    if ticker_label == null: return
    var clean := _strip_bbcode(msg)
    ticker_label.text = clean
    ticker_label.visible = true
    ticker_label.modulate.a = 0.0
    var tw := create_tween()
    tw.tween_property(ticker_label, "modulate:a", 1.0, 0.15)
    tw.tween_interval(2.2)
    tw.tween_property(ticker_label, "modulate:a", 0.0, 0.4)
    tw.tween_callback(func(): ticker_label.visible = false)


func _strip_bbcode(s: String) -> String:
    var rx := RegEx.new()
    rx.compile("\\[/?[^\\]]+\\]")
    return rx.sub(s, "", true)


func _toggle_log_panel() -> void:
    SoundFX.play(&"click")
    log_panel.visible = not log_panel.visible
    log_toggle_button.text = "×" if log_panel.visible else "?"


# ─── Online ───────────────────────────────────────────────────────────────────

func _on_host_pressed() -> void:
    var port: int = int(lobby_port_input.text) if lobby_port_input.text.is_valid_int() else NetworkManager.DEFAULT_PORT
    if NetworkManager.host_game(port, lobby_name_input.text, lobby_password_input.text):
        lobby_start_button.disabled = false
        var pw_note: String = " (mot de passe activé)" if lobby_password_input.text != "" else ""
        _log("[color=#88ccff]🌐 Partie hébergée sur port %d%s[/color]" % [port, pw_note])


func _on_join_pressed() -> void:
    var port: int = int(lobby_port_input.text) if lobby_port_input.text.is_valid_int() else NetworkManager.DEFAULT_PORT
    NetworkManager.join_game(lobby_ip_input.text, port, lobby_name_input.text, lobby_password_input.text)
    _log("[color=#88ccff]🌐 Tentative de connexion à %s:%d…[/color]" % [lobby_ip_input.text, port])


func _on_connected_to_host() -> void:
    _log("[color=#88ccff]🌐 Connecté à l'hôte[/color]")


func _on_connection_failed(reason: String) -> void:
    _log("[color=#ff6b6b]🌐 ⛔ %s[/color]" % reason)


func _on_lobby_updated(players: Array) -> void:
    var bb := ""
    var current_peers: Dictionary = {}
    for p in players:
        var tag := " [color=yellow](hôte)[/color]" if p.get("is_host", false) else ""
        bb += "• [b]%s[/b] (siège %d)%s\n" % [p.get("name", "?"), p.get("player_id", -1), tag]
        current_peers[p.get("peer", 0)] = p.get("name", "?")
    lobby_list.text = bb
    # Diff vs précédent → toasts join/leave
    for peer in current_peers:
        if not _previous_lobby_peers.has(peer):
            _show_connection_toast("🟢 %s a rejoint" % current_peers[peer], Color(0.5, 1.0, 0.5))
            SoundFX.play(&"player_join")
    for peer in _previous_lobby_peers:
        if not current_peers.has(peer):
            _show_connection_toast("🔴 %s a quitté" % _previous_lobby_peers[peer], Color(1.0, 0.5, 0.5))
            SoundFX.play(&"player_leave")
    _previous_lobby_peers = current_peers


func _show_connection_toast(text: String, color: Color) -> void:
    if connection_toast == null: return
    var lab := Label.new()
    lab.text = text
    lab.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    lab.add_theme_font_size_override("font_size", 17)
    lab.add_theme_color_override("font_color", color)
    lab.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
    lab.add_theme_constant_override("outline_size", 5)
    lab.modulate.a = 0.0
    connection_toast.add_child(lab)
    var tw := create_tween().set_parallel(true)
    tw.tween_property(lab, "modulate:a", 1.0, 0.2)
    tw.chain().tween_interval(2.4)
    tw.chain().tween_property(lab, "modulate:a", 0.0, 0.4)
    tw.chain().tween_callback(lab.queue_free)


func _on_start_online_pressed() -> void:
    if not NetworkManager.is_host: return
    var nb_players: int = NetworkManager.lobby_players.size()
    if nb_players < 2:
        _log("[color=#ff6b6b]🌐 Il faut au moins 2 joueurs[/color]")
        return
    var config := {
        "nb_decks": maxi(2, int(ceil(nb_players / 2.0))),
        "nb_players": nb_players,
        "cards_dealt": 5,
        "score_target": 50,
        "mode": "online",
        "ai_difficulty": "basic"
    }
    var names: Array = []
    var sorted_lobby: Array = NetworkManager._lobby_array()
    for entry in sorted_lobby:
        names.append(entry.get("name", "Joueur"))
    GameManager.start_game(config, names)
    lobby_dialog.hide()


func _on_leave_online_pressed() -> void:
    NetworkManager.leave()
    lobby_list.text = ""
    lobby_start_button.disabled = true
    _log("[color=#88ccff]🌐 Quitté[/color]")


func _on_remote_event(event_name: String, payload: Dictionary) -> void:
    # Côté client : reçoit les events du host pour log/animation/sound.
    if NetworkManager.is_host: return
    match event_name:
        "card_played":
            var card := Card.create(payload.get("v", 0), payload.get("s", 0))
            var pid: int = payload.get("pid", -1)
            if GameManager.state and pid >= 0 and pid < GameManager.state.players.size():
                _on_card_played(card, pid)
        "card_drawn":
            var pid: int = payload.get("pid", -1)
            var count: int = payload.get("count", 1)
            if pid >= 0:
                var p_name: String = GameManager.state.players[pid].name if (GameManager.state and pid < GameManager.state.players.size()) else ("Joueur %d" % (pid + 1))
                _log("[color=#a8b9d0]%s pioche %d carte(s)[/color]" % [p_name, count])
                SoundFX.play(&"card_draw")
                _animate_draw_to_seat(pid, count)
        "fire_landed":
            _on_fire_landed(payload.get("pid", -1), payload.get("dmg", 0))
        "effect_triggered":
            _on_effect_triggered(payload.get("name", "NONE"), payload.get("payload", {}))
        "round_ended":
            _on_round_ended(payload.get("scores", {}))
        "game_over":
            _on_game_over(payload.get("winner", -1))
        "game_paused":
            var who: String = payload.get("name", "Un joueur")
            _show_pause_popup("%s s'est déconnecté.\nLa partie ne peut plus continuer." % who)


func _on_state_received(state_dict: Dictionary) -> void:
    if NetworkManager.is_host:
        _refresh_all()
        return

    # Client : reconstruit GameManager.state à partir du dict.
    var first_time: bool = GameManager.state == null
    _apply_remote_state(state_dict)
    if first_time:
        lobby_dialog.hide()
        round_end_popup.visible = false
        game_over_popup.visible = false
        _build_seats()
        _log("[b]Partie démarrée (en ligne)[/b]")
        _play_ready_go_countdown()
    _refresh_all()


func _apply_remote_state(d: Dictionary) -> void:
    var st := GameState.new()
    var viewer: int = d.get("viewer_pid", -1)

    for pdata in d.get("players", []):
        var p := Player.create(pdata.get("id", 0), pdata.get("name", "?"), pdata.get("is_ai", false))
        p.score = pdata.get("score", 0)
        p.is_eliminated = pdata.get("is_eliminated", false)
        p.has_called_carte = pdata.get("has_called_carte", false)
        var hand_data: Array = pdata.get("hand", [])
        if hand_data.is_empty():
            # Adversaire : on génère des cartes-fantômes pour respecter la taille
            for i in pdata.get("hand_size", 0):
                p.add_card(Card.create(0, Card.Suit.NONE))  # placeholder, affichées face cachée
        else:
            for cd in hand_data:
                p.add_card(Card.create(cd.get("v", 0), cd.get("s", Card.Suit.NONE)))
        st.players.append(p)

    st.current_player_idx = d.get("current_player_idx", 0)
    st.direction = d.get("direction", 1)
    st.required_suit = d.get("required_suit", -1)
    st.must_replay = d.get("must_replay", false)
    st.replay_chain = d.get("replay_chain", 0)
    st.round_finished = d.get("round_finished", false)
    st.game_finished = d.get("game_finished", false)

    # Deck : on triche en remplissant avec des placeholders pour matcher la taille
    var deck_size: int = d.get("deck_size", 0)
    for i in deck_size:
        st.deck.cards.append(Card.create(0, Card.Suit.NONE))

    var top_data: Dictionary = d.get("discard_top", {})
    if not top_data.is_empty():
        st.discard.push(Card.create(top_data.get("v", 0), top_data.get("s", Card.Suit.NONE)))

    # Fire (pour affichage HUD)
    var fire_data: Dictionary = d.get("active_fire", {})
    if not fire_data.is_empty():
        var fire := GameState.FireSanction.new()
        fire.source_card = Card.create(fire_data.get("src_v", 0), fire_data.get("src_s", 0))
        fire.damage_queue = fire_data.get("queue", [])
        fire.current_damage_idx = fire_data.get("idx", 0)
        st.active_fire = fire

    # Le viewer est notre joueur local : on l'utilise pour l'affichage de la main
    GameManager.state = st
    GameManager.config = {"mode": "online", "score_target": 50, "nb_players": st.players.size()}
    # Mémoriser viewer
    set_meta("viewer_pid", viewer)


# ─── Social Handlers ─────────────────────────────────────────────────────────

func _on_social_message(sender: String, text: String, color: Color) -> void:
    var col_html = color.to_html()
    _log("[color=#%s][b]%s :[/b][/color] %s" % [col_html, sender, text])
    SoundFX.play(&"chat")

func _on_social_reaction(player_id: int, emoji: String) -> void:
    var seat: SeatView = seat_views.get(player_id)
    if seat:
        seat.show_emoji(emoji)


func _on_pings_updated(pings_by_pid: Dictionary) -> void:
    for pid in seat_views:
        var seat: SeatView = seat_views[pid]
        if seat == null: continue
        if pings_by_pid.has(pid):
            seat.set_ping(int(pings_by_pid[pid]))
        else:
            seat.set_ping(-1)


func _on_player_disconnected_mid_game(player_name: String, _player_id: int) -> void:
    _show_pause_popup("%s s'est déconnecté.\nLa partie ne peut plus continuer." % player_name)


func _show_pause_popup(reason: String) -> void:
    if pause_popup == null: return
    pause_reason.text = reason
    pause_popup.modulate = Color(1, 1, 1, 0)
    pause_popup.visible = true
    create_tween().tween_property(pause_popup, "modulate:a", 1.0, 0.25)
    SoundFX.play(&"player_leave")


func _on_chat_send() -> void:
    var t: String = chat_input.text.strip_edges()
    if t.is_empty(): return
    SocialManager.send_chat(t)
    chat_input.clear()
    chat_input.release_focus()


func _on_copy_log_pressed() -> void:
    DisplayServer.clipboard_set(log_label.get_parsed_text())
    var orig := copy_log_button.text
    copy_log_button.text = "✓ Copié"
    var t := create_tween()
    t.tween_interval(1.0)
    t.tween_callback(func(): copy_log_button.text = orig)
