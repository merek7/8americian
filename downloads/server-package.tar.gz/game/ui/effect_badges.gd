class_name EffectBadgesView extends Control
## Rangée de pastilles circulaires montrant les effets actifs (FEU, BLOC, TRF, REJ, SAUT, INV).

const BADGE_SIZE := 54.0
const BADGE_SPACING := 10.0
const LABEL_FONT_SIZE := 13
const PAYLOAD_FONT_SIZE := 12

const EFFECTS := [
    {"key": "fire", "label": "FEU", "color": Color(1.00, 0.45, 0.15)},
    {"key": "block", "label": "BLOC", "color": Color(0.30, 0.65, 1.00)},
    {"key": "transfer", "label": "TRF", "color": Color(0.78, 0.42, 0.95)},
    {"key": "replay", "label": "REJ", "color": Color(0.60, 0.50, 0.92)},
    {"key": "skip", "label": "SAUT", "color": Color(0.40, 0.85, 0.95)},
    {"key": "reverse", "label": "INV", "color": Color(0.45, 0.90, 0.50)},
]

var _active: Dictionary = {}
var _flash_until: Dictionary = {}
var _payload: Dictionary = {}
var _pulse: float = 0.0
var _activate_until: Dictionary = {}  # key -> ticks_msec d'arrêt de l'animation pop


func _ready() -> void:
    custom_minimum_size = Vector2(BADGE_SIZE * EFFECTS.size() + BADGE_SPACING * (EFFECTS.size() - 1), BADGE_SIZE)
    for e in EFFECTS:
        _active[e.key] = false
        _flash_until[e.key] = 0
        _payload[e.key] = null


func _process(_delta: float) -> void:
    var any_on := false
    for k in _active.keys():
        if _active[k]:
            any_on = true
            break
    var now := Time.get_ticks_msec()
    for k in _flash_until.keys():
        if _flash_until[k] > 0:
            if _flash_until[k] < now:
                _flash_until[k] = 0
            else:
                any_on = true
    var any_pop := false
    for k in _activate_until.keys():
        if _activate_until[k] > now:
            any_pop = true
    if any_on:
        _pulse = (sin(float(now) / 380.0) + 1.0) * 0.5
    if any_on or any_pop:
        queue_redraw()


func set_state(state) -> void:
    if state == null:
        for k in _active.keys(): _active[k] = false
        queue_redraw()
        return
    var now := Time.get_ticks_msec()
    var new_active := {
        "fire": state.active_fire != null,
        "block": state.required_suit >= 0,
        "transfer": state.active_transfer != null,
        "replay": state.must_replay or state.replay_chain > 0,
        "skip": state.pending_skip > 0,
    }
    for k in new_active.keys():
        if new_active[k] and not _active.get(k, false):
            _activate_until[k] = now + 280
        _active[k] = new_active[k]
    _payload["fire"] = state.active_fire.current_damage() if state.active_fire != null else null
    _payload["block"] = state.required_suit
    _payload["replay"] = state.replay_chain
    _payload["skip"] = state.pending_skip
    queue_redraw()


func flash(key: String, duration_ms: int = 1500) -> void:
    if not _flash_until.has(key): return
    _flash_until[key] = Time.get_ticks_msec() + duration_ms
    queue_redraw()


func _draw() -> void:
    var f := ThemeDB.fallback_font
    var now := Time.get_ticks_msec()
    # Fond rounded subtil derrière toute la rangée
    var total_w: float = BADGE_SIZE * EFFECTS.size() + BADGE_SPACING * (EFFECTS.size() - 1)
    var bg_rect := Rect2(Vector2(-8, -6), Vector2(total_w + 16, BADGE_SIZE + 12))
    _rounded_fill(bg_rect, 16.0, Color(0.04, 0.10, 0.07, 0.55))
    _rounded_border(bg_rect, 16.0, Color(1.0, 0.92, 0.45, 0.18), 1.0)
    var x: float = 0.0
    for e in EFFECTS:
        var center := Vector2(x + BADGE_SIZE / 2.0, BADGE_SIZE / 2.0)
        var r: float = BADGE_SIZE / 2.0 - 3.0
        var col: Color = e.color
        var is_on: bool = _active.get(e.key, false) or _flash_until.get(e.key, 0) > 0
        # Pop animation à l'activation (échelle bouncy 0→1.18→1.0)
        var act_end: int = _activate_until.get(e.key, 0)
        var pop: float = 1.0
        if act_end > now:
            var t: float = 1.0 - float(act_end - now) / 280.0  # 0→1
            pop = 1.0 + 0.18 * sin(t * PI)
            r *= pop
        var fg: Color

        if is_on:
            var halo_r: float = r + 4.0 + _pulse * 4.0
            draw_circle(center, halo_r, Color(col.r, col.g, col.b, 0.35 * (0.55 + 0.45 * _pulse)))
            draw_circle(center, r, col)
            draw_arc(center, r, 0.0, TAU, 48, Color(1.0, 1.0, 1.0, 0.85), 2.0, true)
            fg = Color(0.05, 0.05, 0.05, 0.95)
        else:
            draw_circle(center, r, Color(col.r * 0.20, col.g * 0.20, col.b * 0.20, 0.55))
            draw_arc(center, r, 0.0, TAU, 48, Color(col.r, col.g, col.b, 0.40), 1.5, true)
            fg = Color(0.70, 0.78, 0.74, 0.65)

        var ts := f.get_string_size(e.label, HORIZONTAL_ALIGNMENT_CENTER, -1, LABEL_FONT_SIZE)
        draw_string(f, center - ts / 2.0 + Vector2(0, ts.y / 4.0), e.label,
                    HORIZONTAL_ALIGNMENT_CENTER, -1, LABEL_FONT_SIZE, fg)

        if is_on:
            var pld = _payload.get(e.key)
            var lbl: String = ""
            if pld != null:
                match e.key:
                    "fire":
                        if int(pld) > 0: lbl = "+%d" % int(pld)
                    "replay":
                        if int(pld) > 1: lbl = "x%d" % int(pld)
                    "skip":
                        if int(pld) > 1: lbl = "x%d" % int(pld)
                    "block":
                        var sname := ["♥", "♦", "♣", "♠"]
                        if int(pld) >= 0 and int(pld) < 4: lbl = sname[int(pld)]
            if not lbl.is_empty():
                var bp := center + Vector2(r * 0.6, -r * 0.6)
                draw_circle(bp, 11.0, Color(0.05, 0.05, 0.05, 0.92))
                draw_arc(bp, 11.0, 0.0, TAU, 24, Color(1.0, 0.92, 0.45, 0.95), 1.5, true)
                var pts2 := f.get_string_size(lbl, HORIZONTAL_ALIGNMENT_CENTER, -1, PAYLOAD_FONT_SIZE)
                draw_string(f, bp - pts2 / 2.0 + Vector2(0, pts2.y / 4.0), lbl,
                            HORIZONTAL_ALIGNMENT_CENTER, -1, PAYLOAD_FONT_SIZE, Color(1.0, 0.92, 0.45, 1.0))

        x += BADGE_SIZE + BADGE_SPACING


func _rounded_fill(rect: Rect2, r: float, color: Color) -> void:
    draw_colored_polygon(_round_corners(rect, r), color)


func _rounded_border(rect: Rect2, r: float, color: Color, w: float) -> void:
    var pts := _round_corners(rect, r)
    pts.append(pts[0])
    draw_polyline(pts, color, w, true)


func _round_corners(rect: Rect2, r: float) -> PackedVector2Array:
    var p := PackedVector2Array()
    var corners := [
        Vector2(rect.position.x + r, rect.position.y + r),
        Vector2(rect.position.x + rect.size.x - r, rect.position.y + r),
        Vector2(rect.position.x + rect.size.x - r, rect.position.y + rect.size.y - r),
        Vector2(rect.position.x + r, rect.position.y + rect.size.y - r),
    ]
    var starts := [PI, -PI / 2.0, 0.0, PI / 2.0]
    for i in 4:
        for s in 7:
            var t: float = starts[i] + (PI / 2.0) * (float(s) / 6.0)
            p.append(corners[i] + Vector2(cos(t), sin(t)) * r)
    return p
