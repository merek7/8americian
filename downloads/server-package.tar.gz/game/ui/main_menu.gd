extends Control

@onready var splash_title: Label = $SplashTitle
@onready var splash_sub: Label = $SplashSub
@onready var center: VBoxContainer = $Center
@onready var top_right: HBoxContainer = $TopRight
@onready var blur_overlay: ColorRect = $BlurOverlay
@onready var dim_overlay: ColorRect = $DimOverlay

@onready var solo_button: Button = $Center/Card/V/Solo
@onready var local_button: Button = $Center/Card/V/Local
@onready var online_button: Button = $Center/Card/V/Online
@onready var tournament_button: Button = $Center/Card/V/Tournament
@onready var quit_button: Button = $Center/Card/V/Quit
@onready var tutorial_button: Button = $Center/Card/V/Tutorial
@onready var settings_button: Button = $TopRight/Settings
@onready var stats_button: Button = $TopRight/Stats
@onready var tournament_popup: ColorRect = $TournamentPopup
@onready var t_mode: OptionButton = $TournamentPopup/Panel/V/ModeRow/ModeOption
@onready var t_games: OptionButton = $TournamentPopup/Panel/V/GamesRow/GamesOption
@onready var t_diff: OptionButton = $TournamentPopup/Panel/V/DiffRow/DiffOption
@onready var t_diff_row: HBoxContainer = $TournamentPopup/Panel/V/DiffRow
@onready var t_aicount_row: HBoxContainer = $TournamentPopup/Panel/V/AiCountRow
@onready var t_aicount: SpinBox = $TournamentPopup/Panel/V/AiCountRow/AiCountSpin
@onready var t_cancel: Button = $TournamentPopup/Panel/V/HBtns/TCancel
@onready var t_start: Button = $TournamentPopup/Panel/V/HBtns/TStart
@onready var stats_popup: ColorRect = $StatsPopup
@onready var stats_body: RichTextLabel = $StatsPopup/Panel/V/Body
@onready var stats_close: Button = $StatsPopup/Panel/V/StatsClose
@onready var options_popup: ColorRect = $OptionsPopup
@onready var volume_slider: HSlider = $OptionsPopup/Panel/V/VolumeRow/VolumeSlider
@onready var fullscreen_check: CheckButton = $OptionsPopup/Panel/V/FullscreenRow/FullscreenCheck
@onready var difficulty_option: OptionButton = $OptionsPopup/Panel/V/DiffRow/DifficultyOption
@onready var close_options_btn: Button = $OptionsPopup/Panel/V/CloseBtn
@onready var pseudo_input: LineEdit = $OptionsPopup/Panel/V/PseudoRow/PseudoInput
@onready var avatar_picker: HBoxContainer = $OptionsPopup/Panel/V/AvatarRow/AvatarPicker
@onready var felt_picker: HBoxContainer = $OptionsPopup/Panel/V/FeltRow/FeltPicker
@onready var stats_label: Label = $OptionsPopup/Panel/V/StatsLabel
@onready var new_game_popup: ColorRect = $NewGamePopup
@onready var ng_mode_label: Label = $NewGamePopup/Panel/V/NgMode
@onready var ng_players: SpinBox = $NewGamePopup/Panel/V/PlayersRow/PlayersSpin
@onready var ng_score: OptionButton = $NewGamePopup/Panel/V/ScoreRow/ScoreOption
@onready var ng_cards: OptionButton = $NewGamePopup/Panel/V/CardsRow/CardsOption
@onready var ng_cancel: Button = $NewGamePopup/Panel/V/HBtns/NgCancel
@onready var ng_start: Button = $NewGamePopup/Panel/V/HBtns/NgStart

var _pending_mode: String = ""


func _ready() -> void:
    solo_button.pressed.connect(func(): _open_new_game("solo_vs_ai"))
    local_button.pressed.connect(func(): _open_new_game("local_multi"))
    online_button.pressed.connect(func(): _launch("online"))
    tournament_button.pressed.connect(_open_tournament)
    ng_cancel.pressed.connect(_close_new_game)
    ng_start.pressed.connect(_confirm_new_game)
    quit_button.pressed.connect(func(): get_tree().quit())
    tutorial_button.pressed.connect(_open_tutorial)
    settings_button.pressed.connect(_on_settings)
    stats_button.pressed.connect(_open_stats)
    t_cancel.pressed.connect(_close_tournament)
    t_start.pressed.connect(_start_tournament)
    t_mode.item_selected.connect(func(_idx): _refresh_tournament_rows())
    stats_close.pressed.connect(_close_stats)
    _ready_options()

    var args := OS.get_cmdline_user_args()
    if "--server" in args:
        _launch("online_server_auto")
        return

    _play_splash_then_menu()

    # 1ère partie : suggérer le tutoriel
    if has_node("/root/Profile") and not Profile.tutorial_done and Profile.games_played == 0:
        await get_tree().create_timer(2.4).timeout
        _suggest_tutorial()


func _suggest_tutorial() -> void:
    var dlg := ConfirmationDialog.new()
    dlg.title = "Première fois ?"
    dlg.dialog_text = "Veux-tu lancer le tutoriel pour découvrir les règles ?"
    dlg.ok_button_text = "Oui, montrer le tutoriel"
    dlg.cancel_button_text = "Non, je connais"
    add_child(dlg)
    dlg.confirmed.connect(_open_tutorial)
    dlg.canceled.connect(func():
        if has_node("/root/Profile"):
            Profile.tutorial_done = true
            Profile.save_profile()
        dlg.queue_free()
    )
    dlg.popup_centered()


func _play_splash_then_menu() -> void:
    splash_title.modulate.a = 0.0
    splash_title.scale = Vector2(0.85, 0.85)
    splash_title.pivot_offset = splash_title.size / 2.0
    splash_sub.modulate.a = 0.0

    var t1 := create_tween().set_parallel(true)
    t1.tween_property(splash_title, "modulate:a", 1.0, 0.5)
    t1.tween_property(splash_title, "scale", Vector2.ONE, 0.6).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    t1.chain().tween_property(splash_sub, "modulate:a", 1.0, 0.4)
    t1.chain().tween_interval(1.4)
    t1.chain().tween_callback(_transition_to_menu)


func _transition_to_menu() -> void:
    # Cache le splash, applique le blur en montant à 4.0, dim, puis le menu apparaît
    var t := create_tween().set_parallel(true)

    # Le splash s'éclipse vers le haut + fade
    t.tween_property(splash_title, "modulate:a", 0.0, 0.45)
    t.tween_property(splash_title, "position:y", splash_title.position.y - 40, 0.45).set_trans(Tween.TRANS_CUBIC)
    t.tween_property(splash_sub, "modulate:a", 0.0, 0.35)

    # Blur monte
    t.tween_method(_set_blur, 0.0, 3.5, 0.5)
    # Voile sombre
    t.tween_property(dim_overlay, "modulate:a", 1.0, 0.5)

    # Le menu apparaît
    t.chain().tween_callback(func():
        center.visible = true
        center.modulate.a = 0.0
        center.scale = Vector2(0.95, 0.95)
        center.pivot_offset = center.size / 2.0
        top_right.visible = true
        top_right.modulate.a = 0.0
        var t2 := create_tween().set_parallel(true)
        t2.tween_property(center, "modulate:a", 1.0, 0.45)
        t2.tween_property(center, "scale", Vector2.ONE, 0.55).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
        t2.tween_property(top_right, "modulate:a", 1.0, 0.45)
    )


func _set_blur(amount: float) -> void:
    if blur_overlay.material:
        var mat: ShaderMaterial = blur_overlay.material
        mat.set_shader_parameter("blur_amount", amount)


func _open_tutorial() -> void:
    if has_node("/root/SoundFX"): SoundFX.play(&"click")
    var tw := create_tween()
    tw.tween_property(self, "modulate:a", 0.0, 0.2)
    tw.tween_callback(func(): get_tree().change_scene_to_file("res://ui/tutorial.tscn"))


func _open_new_game(mode: String) -> void:
    _pending_mode = mode
    if has_node("/root/SoundFX"): SoundFX.play(&"click")
    ng_mode_label.text = "Solo vs IA" if mode == "solo_vs_ai" else "Multijoueur local"
    new_game_popup.visible = true
    new_game_popup.modulate = Color(1, 1, 1, 0)
    create_tween().tween_property(new_game_popup, "modulate:a", 1.0, 0.2)


func _close_new_game() -> void:
    if has_node("/root/SoundFX"): SoundFX.play(&"click")
    var tw := create_tween()
    tw.tween_property(new_game_popup, "modulate:a", 0.0, 0.18)
    tw.tween_callback(func(): new_game_popup.visible = false)


func _confirm_new_game() -> void:
    if has_node("/root/SoundFX"): SoundFX.play(&"click")
    GameSession.pending_launch = {
        "mode": _pending_mode,
        "nb_players": int(ng_players.value),
        "score_target": ng_score.get_selected_id(),
        "cards_dealt": ng_cards.get_selected_id()
    }
    new_game_popup.visible = false
    var tw := create_tween()
    tw.tween_property(self, "modulate:a", 0.0, 0.25)
    tw.tween_callback(func(): get_tree().change_scene_to_file("res://ui/main_scene.tscn"))


func _launch(mode: String) -> void:
    if has_node("/root/SoundFX"):
        SoundFX.play(&"click")
    var data := {"mode": mode}
    GameSession.pending_launch = data
    var tw := create_tween()
    tw.tween_property(self, "modulate:a", 0.0, 0.25)
    tw.tween_callback(func(): get_tree().change_scene_to_file("res://ui/main_scene.tscn"))


func _open_tournament() -> void:
    if has_node("/root/SoundFX"): SoundFX.play(&"click")
    tournament_popup.visible = true
    tournament_popup.modulate = Color(1, 1, 1, 0)
    create_tween().tween_property(tournament_popup, "modulate:a", 1.0, 0.2)
    _refresh_tournament_rows()


func _close_tournament() -> void:
    if has_node("/root/SoundFX"): SoundFX.play(&"click")
    var tw := create_tween()
    tw.tween_property(tournament_popup, "modulate:a", 0.0, 0.18)
    tw.tween_callback(func(): tournament_popup.visible = false)


func _refresh_tournament_rows() -> void:
    var mode_idx := t_mode.selected
    # 0 = career : ni diff ni count visibles (auto)
    # 1 = multi_ai : count visible, diff cachée
    # 2 = best_of_n : diff visible, count caché
    t_diff_row.visible = (mode_idx == 2)
    t_aicount_row.visible = (mode_idx == 1)


func _start_tournament() -> void:
    if has_node("/root/SoundFX"): SoundFX.play(&"click")
    var nb_games: int = t_games.get_selected_id()
    var mode_idx: int = t_mode.selected
    match mode_idx:
        0: Tournament.start_career(nb_games)
        1: Tournament.start_multi_ai(int(t_aicount.value), nb_games)
        2:
            var diffs := ["basic", "medium", "hard"]
            Tournament.start_best_of_n(diffs[t_diff.selected], nb_games)
    tournament_popup.visible = false
    GameSession.pending_launch = Tournament.next_game_config()
    var tw := create_tween()
    tw.tween_property(self, "modulate:a", 0.0, 0.25)
    tw.tween_callback(func(): get_tree().change_scene_to_file("res://ui/main_scene.tscn"))


func _open_stats() -> void:
    if has_node("/root/SoundFX"): SoundFX.play(&"click")
    _refresh_stats_body()
    stats_popup.visible = true
    stats_popup.modulate = Color(1, 1, 1, 0)
    create_tween().tween_property(stats_popup, "modulate:a", 1.0, 0.2)


func _close_stats() -> void:
    if has_node("/root/SoundFX"): SoundFX.play(&"click")
    var tw := create_tween()
    tw.tween_property(stats_popup, "modulate:a", 0.0, 0.18)
    tw.tween_callback(func(): stats_popup.visible = false)


func _refresh_stats_body() -> void:
    var p := Profile
    var rate: float = (float(p.games_won) / float(p.games_played) * 100.0) if p.games_played > 0 else 0.0
    var bb: String = ""
    bb += "[b]Total joué :[/b] %d   •   [b]Victoires :[/b] %d  ([color=#ffe066]%.0f%%[/color])\n\n" % [p.games_played, p.games_won, rate]
    bb += "[b]Par difficulté :[/b]\n"
    var labels := {"basic": "Basique", "medium": "Medium", "hard": "Hard"}
    for d in ["basic", "medium", "hard"]:
        var played: int = int(p.stats_per_diff[d]["played"])
        var won: int = int(p.stats_per_diff[d]["won"])
        var r: float = (float(won) / float(played) * 100.0) if played > 0 else 0.0
        bb += "  • %s : [b]%d / %d[/b]  ([color=#ffe066]%.0f%%[/color])\n" % [labels[d], won, played, r]
    bb += "\n[b]Série en cours :[/b] %d   •   [b]Meilleure série :[/b] %d\n" % [p.current_streak, p.longest_streak]
    var bs_str: String = "—" if p.best_score < 0 else "%d pts" % p.best_score
    bb += "[b]Meilleur score :[/b] %s\n\n" % bs_str
    var trate: float = (float(p.tournaments_won) / float(p.tournaments_played) * 100.0) if p.tournaments_played > 0 else 0.0
    bb += "[b]Tournois :[/b] %d / %d  ([color=#ffe066]%.0f%%[/color])\n" % [p.tournaments_won, p.tournaments_played, trate]
    bb += "[b]Multi local :[/b] %d   •   [b]En ligne :[/b] %d" % [p.total_local_games, p.total_online_games]
    stats_body.text = bb


func _on_settings() -> void:
    if has_node("/root/SoundFX"): SoundFX.play(&"click")
    options_popup.visible = true
    options_popup.modulate.a = 0.0
    create_tween().tween_property(options_popup, "modulate:a", 1.0, 0.2)


func _ready_options() -> void:
    var bus_master := AudioServer.get_bus_index("Master")
    volume_slider.value = AudioServer.get_bus_volume_db(bus_master)
    volume_slider.value_changed.connect(func(v):
        AudioServer.set_bus_volume_db(bus_master, v)
    )
    fullscreen_check.button_pressed = (DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN)
    fullscreen_check.toggled.connect(func(on):
        DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if on else DisplayServer.WINDOW_MODE_WINDOWED)
    )
    close_options_btn.pressed.connect(func():
        if has_node("/root/SoundFX"): SoundFX.play(&"click")
        var tw := create_tween()
        tw.tween_property(options_popup, "modulate:a", 0.0, 0.18)
        tw.tween_callback(func(): options_popup.visible = false)
    )

    pseudo_input.text = Profile.pseudo
    pseudo_input.text_changed.connect(func(t): Profile.set_pseudo(t))
    _build_avatar_picker()
    _build_felt_picker()
    _refresh_stats()
    Profile.profile_changed.connect(func(): _refresh_stats(); _build_avatar_picker(); _build_felt_picker())

    var diff_idx: int = {"basic": 0, "medium": 1, "hard": 2}.get(Profile.ai_difficulty, 0)
    difficulty_option.selected = diff_idx
    difficulty_option.item_selected.connect(func(idx):
        Profile.ai_difficulty = ["basic", "medium", "hard"][idx]
        Profile.save_profile()
    )


func _build_avatar_picker() -> void:
    for c in avatar_picker.get_children():
        avatar_picker.remove_child(c)
        c.queue_free()
    for i in Profile.AVATAR_COLORS.size():
        var btn := Button.new()
        btn.custom_minimum_size = Vector2(34, 34)
        btn.text = "✓" if i == Profile.avatar_index else ""
        var sb := StyleBoxFlat.new()
        sb.bg_color = Profile.AVATAR_COLORS[i]
        sb.corner_radius_top_left = 17
        sb.corner_radius_top_right = 17
        sb.corner_radius_bottom_left = 17
        sb.corner_radius_bottom_right = 17
        sb.border_width_top = 2
        sb.border_width_bottom = 2
        sb.border_width_left = 2
        sb.border_width_right = 2
        sb.border_color = Color.WHITE if i == Profile.avatar_index else Color(1, 1, 1, 0.3)
        btn.add_theme_stylebox_override("normal", sb)
        btn.add_theme_stylebox_override("hover", sb)
        btn.add_theme_stylebox_override("pressed", sb)
        var idx := i
        btn.pressed.connect(func(): Profile.set_avatar_index(idx))
        avatar_picker.add_child(btn)


func _build_felt_picker() -> void:
    var FeltScript = preload("res://ui/felt_background.gd")
    for c in felt_picker.get_children():
        felt_picker.remove_child(c)
        c.queue_free()
    var presets: Array = FeltScript.FELT_PRESETS
    for i in presets.size():
        var btn := Button.new()
        btn.custom_minimum_size = Vector2(54, 30)
        btn.tooltip_text = presets[i].name
        btn.text = "✓" if i == Profile.felt_choice else ""
        var sb := StyleBoxFlat.new()
        sb.bg_color = presets[i].inner
        sb.corner_radius_top_left = 6
        sb.corner_radius_top_right = 6
        sb.corner_radius_bottom_left = 6
        sb.corner_radius_bottom_right = 6
        sb.border_width_top = 2
        sb.border_width_bottom = 2
        sb.border_width_left = 2
        sb.border_width_right = 2
        sb.border_color = Color(1, 0.92, 0.45) if i == Profile.felt_choice else Color(1, 1, 1, 0.25)
        btn.add_theme_stylebox_override("normal", sb)
        btn.add_theme_stylebox_override("hover", sb)
        btn.add_theme_stylebox_override("pressed", sb)
        var idx := i
        btn.pressed.connect(func(): Profile.set_felt_choice(idx))
        felt_picker.add_child(btn)


func _refresh_stats() -> void:
    stats_label.text = "Parties jouées : %d   •   Victoires : %d" % [Profile.games_played, Profile.games_won]
