class_name CardView extends Control
## Carte rendue programmatiquement. Suits dessinés en _draw() pour couleurs fidèles.

signal card_clicked(card: Card)

const CARD_SIZE := Vector2(88, 124)
const RED_SUITS := [Card.Suit.HEART, Card.Suit.DIAMOND]

var card: Card = null
var is_playable: bool = false
var face_down: bool = false
var _hovering: bool = false


func _ready() -> void:
    custom_minimum_size = CARD_SIZE
    mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
    mouse_filter = Control.MOUSE_FILTER_STOP
    mouse_entered.connect(_on_hover_in)
    mouse_exited.connect(_on_hover_out)
    queue_redraw()


func _on_hover_in() -> void:
    _hovering = true
    queue_redraw()
    if is_playable and not face_down:
        pivot_offset = size / 2.0
        var tw := create_tween()
        tw.tween_property(self, "scale", Vector2(1.12, 1.12), 0.12).set_trans(Tween.TRANS_CUBIC)


func _on_hover_out() -> void:
    _hovering = false
    queue_redraw()
    var tw := create_tween()
    tw.tween_property(self, "scale", Vector2.ONE, 0.12).set_trans(Tween.TRANS_CUBIC)


func setup(p_card: Card, p_face_down: bool = false) -> void:
    card = p_card
    face_down = p_face_down
    queue_redraw()


func set_playable(playable: bool) -> void:
    is_playable = playable
    queue_redraw()


func _gui_input(event: InputEvent) -> void:
    if event is InputEventMouseButton:
        var mb: InputEventMouseButton = event
        if mb.pressed and mb.button_index == MOUSE_BUTTON_LEFT and not face_down:
            card_clicked.emit(card)


func _draw() -> void:
    var sz := size if size != Vector2.ZERO else CARD_SIZE
    var rect := Rect2(Vector2.ZERO, sz)
    var radius: float = 9.0

    # Ombre douce
    _draw_rounded_rect(Rect2(Vector2(3, 5), sz), radius, Color(0, 0, 0, 0.40))

    # Fond avec gradient subtil (clair en haut, plus mat en bas)
    var bg_top: Color
    var bg_bottom: Color
    if face_down:
        bg_top = Color(0.18, 0.24, 0.55)
        bg_bottom = Color(0.10, 0.14, 0.40)
    elif is_playable:
        bg_top = Color(1.0, 1.0, 0.97)
        bg_bottom = Color(0.93, 0.93, 0.88)
    else:
        bg_top = Color(0.82, 0.82, 0.78)
        bg_bottom = Color(0.68, 0.68, 0.64)
    _draw_rounded_rect(rect, radius, bg_top)
    # Demi-rectangle bas plus sombre, avec coins arrondis bas seulement
    var bot := Rect2(rect.position + Vector2(0, sz.y * 0.55), Vector2(sz.x, sz.y * 0.45))
    _draw_rounded_rect_partial(bot, radius, bg_bottom)

    # Bordure
    var border_color: Color
    var border_width: float
    if _hovering and is_playable:
        border_color = Color(1.0, 0.85, 0.25); border_width = 3.5
    elif is_playable:
        border_color = Color(0.20, 0.75, 0.35); border_width = 2.5
    else:
        border_color = Color(0.25, 0.25, 0.25); border_width = 1.5
    _draw_rounded_border(rect, radius, border_color, border_width)

    if face_down or card == null:
        _draw_card_back(rect)
        return

    var fc: Color = Color(0.85, 0.13, 0.13) if card.suit in RED_SUITS else Color(0.05, 0.05, 0.05)
    if card.is_joker():
        fc = Color(0.85, 0.5, 0.05)

    var f := ThemeDB.fallback_font

    # Image personnalisée (J/Q/K/Joker) si dispo, sinon fallback procédural
    var face_tex: Texture2D = CardAssets.face_texture(card)
    if face_tex != null:
        var inset: float = 4.0
        var inner := Rect2(rect.position + Vector2(inset, inset),
                           rect.size - Vector2(inset * 2, inset * 2))
        draw_texture_rect(face_tex, inner, false)
        # Ajoute coins valeur+suit par-dessus pour rester lisible
        if not card.is_joker():
            var v_str_t: String = _value_str(card.value)
            var v_size_t: int = 14 if v_str_t.length() > 1 else 17
            var pad: float = 6.0
            var ts_t: Vector2 = f.get_string_size(v_str_t, HORIZONTAL_ALIGNMENT_LEFT, -1, v_size_t)
            draw_string(f, Vector2(pad, pad + v_size_t), v_str_t,
                        HORIZONTAL_ALIGNMENT_LEFT, -1, v_size_t, fc)
            _draw_suit(card.suit, Vector2(pad + ts_t.x / 2.0, pad + v_size_t + 8.0), 5.0, fc)
            var bx_t: float = sz.x - pad - ts_t.x
            var by_t: float = sz.y - pad - 4.0
            draw_string(f, Vector2(bx_t, by_t), v_str_t, HORIZONTAL_ALIGNMENT_LEFT, -1, v_size_t, fc)
            _draw_suit(card.suit, Vector2(bx_t + ts_t.x / 2.0, by_t - v_size_t - 4.0), 5.0, fc)
        return

    if card.is_joker():
        draw_string(f, Vector2(0, sz.y / 2.0 - 2), "JOKER",
                    HORIZONTAL_ALIGNMENT_CENTER, sz.x, 18, fc)
        _draw_suit(card.suit, Vector2(sz.x / 2.0, sz.y / 2.0 + 22), 14.0, fc)
        return

    var v_str: String = _value_str(card.value)
    var corner_pad: float = 6.0

    # Coin haut-gauche : valeur + suit l'un sous l'autre, centrés
    var v_size: int = 14 if v_str.length() > 1 else 17
    var ts: Vector2 = f.get_string_size(v_str, HORIZONTAL_ALIGNMENT_LEFT, -1, v_size)
    draw_string(f, Vector2(corner_pad, corner_pad + v_size), v_str,
                HORIZONTAL_ALIGNMENT_LEFT, -1, v_size, fc)
    _draw_suit(card.suit, Vector2(corner_pad + ts.x / 2.0, corner_pad + v_size + 8.0), 5.0, fc)

    # Coin bas-droit : symétrique sans rotation pour rester lisible
    var bx: float = sz.x - corner_pad - ts.x
    var by: float = sz.y - corner_pad - 4.0
    draw_string(f, Vector2(bx, by), v_str, HORIZONTAL_ALIGNMENT_LEFT, -1, v_size, fc)
    _draw_suit(card.suit, Vector2(bx + ts.x / 2.0, by - v_size - 4.0), 5.0, fc)

    # Centre — gros symbole
    _draw_suit(card.suit, Vector2(sz.x / 2.0, sz.y / 2.0 + 2), 18.0, fc)


func _draw_card_back(rect: Rect2) -> void:
    var back_tex: Texture2D = CardAssets.back_texture()
    if back_tex != null:
        var inset_t: float = 4.0
        var inner_t := Rect2(rect.position + Vector2(inset_t, inset_t),
                              rect.size - Vector2(inset_t * 2, inset_t * 2))
        draw_texture_rect(back_tex, inner_t, false)
        return
    var inset: float = 7.0
    var inner := Rect2(rect.position + Vector2(inset, inset), rect.size - Vector2(inset * 2, inset * 2))
    # Motif losange entrelacé
    var step := 10.0
    var t: float = -rect.size.y
    while t < rect.size.x + rect.size.y:
        draw_line(Vector2(t, 0), Vector2(t + rect.size.y, rect.size.y),
                  Color(0.30, 0.40, 0.70, 0.45), 1.2)
        draw_line(Vector2(t + rect.size.y, 0), Vector2(t, rect.size.y),
                  Color(0.30, 0.40, 0.70, 0.45), 1.2)
        t += step
    # Cadre central
    _draw_rounded_border(inner, 5.0, Color(0.95, 0.95, 1.0, 0.55), 1.6)
    # Logo central (lozange + suit étoilé)
    var c := rect.size / 2.0
    draw_circle(c, 14, Color(0.10, 0.14, 0.36, 0.85))
    draw_arc(c, 14, 0, TAU, 32, Color(1, 0.92, 0.45, 0.9), 1.5)
    var f := ThemeDB.fallback_font
    var sz_text := f.get_string_size("8", HORIZONTAL_ALIGNMENT_CENTER, -1, 16)
    draw_string(f, c - sz_text / 2.0 + Vector2(0, 5), "8",
                HORIZONTAL_ALIGNMENT_CENTER, -1, 16, Color(1, 0.92, 0.45, 1))


func _draw_suit(suit: int, center: Vector2, sz: float, color: Color) -> void:
    _draw_suit_at_origin(suit, center, sz, color)


func _draw_suit_at_origin(suit: int, center: Vector2, sz: float, color: Color) -> void:
    match suit:
        Card.Suit.HEART:
            _draw_heart(center, sz, color)
        Card.Suit.DIAMOND:
            _draw_diamond(center, sz, color)
        Card.Suit.CLUB:
            _draw_club(center, sz, color)
        Card.Suit.SPADE:
            _draw_spade(center, sz, color)
        _:
            draw_circle(center, sz * 0.6, color)


func _draw_heart(c: Vector2, s: float, col: Color) -> void:
    # Cœur via deux cercles + triangle pointant vers le bas
    var r: float = s * 0.6
    draw_circle(c + Vector2(-r * 0.6, -r * 0.3), r, col)
    draw_circle(c + Vector2(r * 0.6, -r * 0.3), r, col)
    var pts := PackedVector2Array([
        c + Vector2(-s * 1.05, 0),
        c + Vector2(s * 1.05, 0),
        c + Vector2(0, s * 1.2)
    ])
    draw_colored_polygon(pts, col)


func _draw_diamond(c: Vector2, s: float, col: Color) -> void:
    var pts := PackedVector2Array([
        c + Vector2(0, -s * 1.2),
        c + Vector2(s * 0.85, 0),
        c + Vector2(0, s * 1.2),
        c + Vector2(-s * 0.85, 0),
    ])
    draw_colored_polygon(pts, col)


func _draw_club(c: Vector2, s: float, col: Color) -> void:
    var r: float = s * 0.55
    draw_circle(c + Vector2(0, -r * 0.9), r, col)
    draw_circle(c + Vector2(-r * 0.85, r * 0.35), r, col)
    draw_circle(c + Vector2(r * 0.85, r * 0.35), r, col)
    # Tige
    var stem := PackedVector2Array([
        c + Vector2(-s * 0.35, r * 0.3),
        c + Vector2(s * 0.35, r * 0.3),
        c + Vector2(s * 0.55, s * 1.25),
        c + Vector2(-s * 0.55, s * 1.25),
    ])
    draw_colored_polygon(stem, col)


func _draw_spade(c: Vector2, s: float, col: Color) -> void:
    # Cœur inversé + tige
    var r: float = s * 0.6
    draw_circle(c + Vector2(-r * 0.6, r * 0.3), r, col)
    draw_circle(c + Vector2(r * 0.6, r * 0.3), r, col)
    var triangle := PackedVector2Array([
        c + Vector2(-s * 1.05, 0),
        c + Vector2(s * 1.05, 0),
        c + Vector2(0, -s * 1.2)
    ])
    draw_colored_polygon(triangle, col)
    var stem := PackedVector2Array([
        c + Vector2(-s * 0.35, r * 0.7),
        c + Vector2(s * 0.35, r * 0.7),
        c + Vector2(s * 0.55, s * 1.3),
        c + Vector2(-s * 0.55, s * 1.3),
    ])
    draw_colored_polygon(stem, col)


func _draw_rounded_rect(rect: Rect2, r: float, color: Color) -> void:
    draw_colored_polygon(_round_corners(rect, r, 6), color)


func _draw_rounded_rect_partial(rect: Rect2, r: float, color: Color) -> void:
    # Rectangle avec coins inférieurs arrondis seulement (pour gradient bas)
    var p := PackedVector2Array()
    p.append(rect.position)
    p.append(Vector2(rect.position.x + rect.size.x, rect.position.y))
    var br := Vector2(rect.position.x + rect.size.x - r, rect.position.y + rect.size.y - r)
    for s in 7:
        var t: float = -PI / 2.0 + (PI / 2.0) * (float(s) / 6.0)
        p.append(br + Vector2(cos(t), sin(t)) * r)
    var bl := Vector2(rect.position.x + r, rect.position.y + rect.size.y - r)
    for s in 7:
        var t2: float = 0.0 + (PI / 2.0) * (float(s) / 6.0)
        p.append(bl + Vector2(cos(t2), sin(t2)) * r)
    draw_colored_polygon(p, color)


func _draw_rounded_border(rect: Rect2, r: float, color: Color, w: float) -> void:
    var pts := _round_corners(rect, r, 6)
    pts.append(pts[0])
    draw_polyline(pts, color, w, true)


func _round_corners(rect: Rect2, r: float, steps: int) -> PackedVector2Array:
    var p := PackedVector2Array()
    var corners := [
        Vector2(rect.position.x + r, rect.position.y + r),
        Vector2(rect.position.x + rect.size.x - r, rect.position.y + r),
        Vector2(rect.position.x + rect.size.x - r, rect.position.y + rect.size.y - r),
        Vector2(rect.position.x + r, rect.position.y + rect.size.y - r),
    ]
    var starts := [PI, -PI / 2.0, 0.0, PI / 2.0]
    for i in 4:
        for s in steps + 1:
            var t: float = starts[i] + (PI / 2.0) * (float(s) / float(steps))
            p.append(corners[i] + Vector2(cos(t), sin(t)) * r)
    return p


func _value_str(v: int) -> String:
    match v:
        0: return "JK"
        1: return "A"
        11: return "J"
        12: return "Q"
        13: return "K"
        _: return str(v)
