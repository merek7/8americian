extends Control
## Tapis de jeu : dégradé radial + halo central, palette choisie par le profil.

const FELT_PRESETS := [
    {"name": "Vert classique", "outer": Color(0.04, 0.16, 0.10), "inner": Color(0.10, 0.32, 0.20), "halo": Color(0.16, 0.42, 0.26), "border": Color(0.02, 0.10, 0.06)},
    {"name": "Bleu nuit",      "outer": Color(0.04, 0.08, 0.20), "inner": Color(0.10, 0.18, 0.36), "halo": Color(0.18, 0.28, 0.50), "border": Color(0.02, 0.04, 0.12)},
    {"name": "Bordeaux",       "outer": Color(0.18, 0.04, 0.08), "inner": Color(0.36, 0.10, 0.16), "halo": Color(0.50, 0.18, 0.24), "border": Color(0.10, 0.02, 0.04)},
    {"name": "Ardoise",        "outer": Color(0.08, 0.10, 0.12), "inner": Color(0.20, 0.22, 0.26), "halo": Color(0.32, 0.36, 0.42), "border": Color(0.04, 0.06, 0.08)},
    {"name": "Sable doré",     "outer": Color(0.18, 0.12, 0.04), "inner": Color(0.38, 0.28, 0.10), "halo": Color(0.52, 0.40, 0.18), "border": Color(0.10, 0.06, 0.02)},
]


func _draw() -> void:
    var sz := size
    var center := sz / 2.0
    var max_r: float = sz.length() / 2.0

    var idx: int = 0
    if has_node("/root/Profile"):
        idx = clampi(Profile.felt_choice, 0, FELT_PRESETS.size() - 1)
    var preset: Dictionary = FELT_PRESETS[idx]

    # Dégradé radial via cercles concentriques
    var steps := 40
    for i in range(steps, 0, -1):
        var t: float = float(i) / float(steps)
        var r: float = max_r * t
        var col: Color = preset.outer.lerp(preset.inner, 1.0 - t)
        draw_circle(center, r, col)

    # Halo central plus clair
    var halo: Color = preset.halo
    for i in range(20, 0, -1):
        var t2: float = float(i) / 20.0
        draw_circle(center, 220.0 * t2, Color(halo.r, halo.g, halo.b, 0.08))

    # Bordure feutre intérieure
    draw_arc(center, min(sz.x, sz.y) * 0.45, 0, TAU, 64, preset.border, 6.0)


func _ready() -> void:
    resized.connect(queue_redraw)
    if has_node("/root/Profile"):
        Profile.profile_changed.connect(queue_redraw)
