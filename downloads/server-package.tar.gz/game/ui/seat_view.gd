class_name SeatView extends Control
## Siège style AAA poker : avatar circulaire, anneau pulsant, timer arc, badges propres.

const CardViewScript = preload("res://ui/card_view.gd")
const TURN_DURATION := 30.0

const SEAT_PALETTE := [
    Color(0.95, 0.85, 0.25),  # or — joueur local par défaut
    Color(0.40, 0.80, 0.95),  # cyan
    Color(0.95, 0.45, 0.65),  # rose
    Color(0.45, 0.90, 0.50),  # vert
    Color(0.95, 0.55, 0.30),  # orange
    Color(0.75, 0.45, 0.95),  # violet
    Color(0.95, 0.92, 0.55),  # crème
    Color(0.55, 0.65, 0.95),  # bleu doux
    Color(0.95, 0.30, 0.30),  # rouge
    Color(0.30, 0.85, 0.75),  # turquoise
]

const FIRE_HALO := Color(1.00, 0.35, 0.18)
const BLOCK_HALO := Color(0.30, 0.65, 1.00)

@export var is_self: bool = false
@export var seat_size: Vector2 = Vector2(820, 200)

var player: Player = null
var is_active: bool = false
var seat_color: Color = Color(0.95, 0.85, 0.25)
var seat_state: String = "normal"  # "normal" | "fire" | "block"

var hand_container: HBoxContainer
var name_label: Label
var score_badge: Label
var cards_badge: Label
var carte_badge: Label
var avatar_ctrl: Control
var bg_ctrl: Control
var fire_particles: CPUParticles2D

var _pulse: float = 0.0
var _pulse_tween: Tween = null
var _carte_tween: Tween = null
var _timer_ratio: float = 1.0
var _timer_elapsed: float = 0.0
var _eliminated: bool = false


func _ready() -> void:
    custom_minimum_size = seat_size
    _build()


func _process(delta: float) -> void:
    if is_active and _timer_ratio > 0.0:
        _timer_elapsed += delta
        _timer_ratio = clampf(1.0 - _timer_elapsed / TURN_DURATION, 0.0, 1.0)
        if avatar_ctrl: avatar_ctrl.queue_redraw()


func _build() -> void:
    bg_ctrl = Control.new()
    bg_ctrl.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg_ctrl.mouse_filter = Control.MOUSE_FILTER_IGNORE
    bg_ctrl.draw.connect(_draw_bg)
    add_child(bg_ctrl)

    if is_self:
        _build_self_layout()
    else:
        _build_opponent_layout()

    fire_particles = CPUParticles2D.new()
    fire_particles.emitting = false
    fire_particles.amount = 60
    fire_particles.lifetime = 0.8
    fire_particles.one_shot = true
    fire_particles.explosiveness = 0.2
    fire_particles.direction = Vector2(0, -1)
    fire_particles.spread = 25.0
    fire_particles.gravity = Vector2(0, -120)
    fire_particles.initial_velocity_min = 80.0
    fire_particles.initial_velocity_max = 180.0
    fire_particles.scale_amount_min = 4.0
    fire_particles.scale_amount_max = 10.0
    fire_particles.color = Color(1.0, 0.55, 0.1, 1.0)
    var grad := Gradient.new()
    grad.add_point(0.0, Color(1.0, 0.95, 0.4, 1.0))
    grad.add_point(0.4, Color(1.0, 0.55, 0.1, 0.9))
    grad.add_point(1.0, Color(0.4, 0.05, 0.0, 0.0))
    fire_particles.color_ramp = grad
    fire_particles.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
    fire_particles.emission_rect_extents = Vector2(80, 5)
    add_child(fire_particles)


func _build_self_layout() -> void:
    # Layout horizontal large : avatar + infos à gauche, main au centre/droite
    var h := HBoxContainer.new()
    h.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    h.add_theme_constant_override("separation", 16)
    h.offset_left = 18; h.offset_top = 14; h.offset_right = -18; h.offset_bottom = -14
    add_child(h)

    var info_col := VBoxContainer.new()
    info_col.custom_minimum_size = Vector2(180, 0)
    info_col.alignment = BoxContainer.ALIGNMENT_CENTER
    info_col.add_theme_constant_override("separation", 6)
    h.add_child(info_col)

    var avatar_wrap := CenterContainer.new()
    info_col.add_child(avatar_wrap)
    avatar_ctrl = Control.new()
    avatar_ctrl.custom_minimum_size = Vector2(86, 86)
    avatar_ctrl.draw.connect(_draw_avatar)
    avatar_wrap.add_child(avatar_ctrl)

    name_label = Label.new()
    name_label.add_theme_font_size_override("font_size", 17)
    name_label.add_theme_color_override("font_color", Color(1.0, 0.97, 0.88))
    name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    info_col.add_child(name_label)

    var badges := HBoxContainer.new()
    badges.alignment = BoxContainer.ALIGNMENT_CENTER
    badges.add_theme_constant_override("separation", 6)
    info_col.add_child(badges)
    cards_badge = _make_badge(Color(0.20, 0.32, 0.52, 0.85), Color(0.95, 0.97, 1.0))
    score_badge = _make_badge(Color(0.55, 0.42, 0.10, 0.90), Color(1.0, 0.93, 0.55))
    badges.add_child(cards_badge)
    badges.add_child(score_badge)

    carte_badge = Label.new()
    carte_badge.text = "CARTE !"
    carte_badge.add_theme_font_size_override("font_size", 14)
    carte_badge.add_theme_color_override("font_color", Color(1.0, 0.92, 0.30))
    carte_badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    carte_badge.visible = false
    info_col.add_child(carte_badge)

    hand_container = HBoxContainer.new()
    hand_container.add_theme_constant_override("separation", -28)
    hand_container.alignment = BoxContainer.ALIGNMENT_CENTER
    hand_container.size_flags_horizontal = SIZE_EXPAND_FILL
    hand_container.size_flags_vertical = SIZE_EXPAND_FILL
    h.add_child(hand_container)


func _build_opponent_layout() -> void:
    # Layout vertical compact : avatar centré, infos en dessous, mini-stack
    var v := VBoxContainer.new()
    v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    v.add_theme_constant_override("separation", 4)
    v.alignment = BoxContainer.ALIGNMENT_CENTER
    v.offset_left = 10; v.offset_top = 10; v.offset_right = -10; v.offset_bottom = -10
    add_child(v)

    var avatar_wrap := CenterContainer.new()
    v.add_child(avatar_wrap)
    avatar_ctrl = Control.new()
    avatar_ctrl.custom_minimum_size = Vector2(70, 70)
    avatar_ctrl.draw.connect(_draw_avatar)
    avatar_wrap.add_child(avatar_ctrl)

    name_label = Label.new()
    name_label.add_theme_font_size_override("font_size", 15)
    name_label.add_theme_color_override("font_color", Color(1.0, 0.97, 0.88))
    name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(name_label)

    var badges := HBoxContainer.new()
    badges.alignment = BoxContainer.ALIGNMENT_CENTER
    badges.add_theme_constant_override("separation", 4)
    v.add_child(badges)
    cards_badge = _make_badge(Color(0.20, 0.32, 0.52, 0.85), Color(0.95, 0.97, 1.0), 11)
    score_badge = _make_badge(Color(0.55, 0.42, 0.10, 0.90), Color(1.0, 0.93, 0.55), 11)
    badges.add_child(cards_badge)
    badges.add_child(score_badge)

    carte_badge = Label.new()
    carte_badge.text = "CARTE !"
    carte_badge.add_theme_font_size_override("font_size", 11)
    carte_badge.add_theme_color_override("font_color", Color(1.0, 0.92, 0.30))
    carte_badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    carte_badge.visible = false
    v.add_child(carte_badge)

    # Hand container vide pour les adversaires : on dessine un mini-stack via _draw_bg
    hand_container = HBoxContainer.new()
    hand_container.visible = false
    v.add_child(hand_container)


func _make_badge(bg: Color, fg: Color, font_size: int = 12) -> Label:
    var lab := Label.new()
    lab.add_theme_font_size_override("font_size", font_size)
    lab.add_theme_color_override("font_color", fg)
    var sb := StyleBoxFlat.new()
    sb.bg_color = bg
    sb.corner_radius_top_left = 8
    sb.corner_radius_top_right = 8
    sb.corner_radius_bottom_left = 8
    sb.corner_radius_bottom_right = 8
    sb.content_margin_left = 8
    sb.content_margin_right = 8
    sb.content_margin_top = 2
    sb.content_margin_bottom = 2
    lab.add_theme_stylebox_override("normal", sb)
    return lab


func set_player(p: Player) -> void:
    player = p
    if p != null:
        set_eliminated(p.is_eliminated)
    _refresh()


func set_active(active: bool) -> void:
    is_active = active
    if active:
        _timer_elapsed = 0.0
        _timer_ratio = 1.0
        _start_pulse()
    elif seat_state != "fire" and seat_state != "block":
        _stop_pulse()
    if bg_ctrl: bg_ctrl.queue_redraw()
    if avatar_ctrl: avatar_ctrl.queue_redraw()


func set_seat_state(s: String) -> void:
    if seat_state == s: return
    seat_state = s
    var needs_pulse: bool = is_active or (seat_state == "fire" or seat_state == "block")
    if needs_pulse:
        _start_pulse()
    else:
        _stop_pulse()
    if avatar_ctrl: avatar_ctrl.queue_redraw()
    if bg_ctrl: bg_ctrl.queue_redraw()


func set_eliminated(eliminated: bool) -> void:
    _eliminated = eliminated
    modulate.a = 0.45 if eliminated else 1.0
    if bg_ctrl: bg_ctrl.queue_redraw()
    if avatar_ctrl: avatar_ctrl.queue_redraw()


func play_fire_burst() -> void:
    if fire_particles == null: return
    fire_particles.position = Vector2(size.x / 2.0, size.y * 0.85)
    fire_particles.emitting = false
    fire_particles.restart()
    fire_particles.emitting = true


func play_fire_flicker(duration_s: float = 1.5) -> void:
    var prev_state: String = seat_state
    set_seat_state("fire")
    var t := get_tree().create_timer(duration_s)
    t.timeout.connect(func():
        # Ne pas écraser un nouvel état entre-temps
        if seat_state == "fire":
            set_seat_state(prev_state if prev_state != "fire" else "normal")
    )


func refresh_hand(legal_check: Callable = Callable(), card_clicked_cb: Callable = Callable()) -> void:
    if hand_container == null: return
    for child in hand_container.get_children():
        hand_container.remove_child(child)
        child.queue_free()
    if player == null: return
    if not is_self:
        if bg_ctrl: bg_ctrl.queue_redraw()
        _refresh()
        return
    var count: int = player.hand.size()
    for i in count:
        var c = player.hand[i]
        var cv := Control.new()
        cv.set_script(CardViewScript)
        hand_container.add_child(cv)
        cv.setup(c, false)
        if count > 1:
            var t: float = float(i) / float(count - 1)
            cv.rotation = deg_to_rad(lerpf(-3.5, 3.5, t))
            cv.pivot_offset = Vector2(44, 110)
        var playable := false
        if legal_check.is_valid(): playable = legal_check.call(c)
        cv.set_playable(playable)
        if card_clicked_cb.is_valid():
            cv.card_clicked.connect(card_clicked_cb)
    _refresh()


func _refresh() -> void:
    if player == null: return
    name_label.text = player.name
    var cnt := player.hand_size()
    cards_badge.text = "%d carte%s" % [cnt, "s" if cnt > 1 else ""]
    score_badge.text = "%d pts" % player.score
    var show_carte := (cnt == 1 and not player.is_ai)
    if show_carte and not carte_badge.visible:
        carte_badge.visible = true
        _pulse_carte()
    elif not show_carte and carte_badge.visible:
        carte_badge.visible = false
        if _carte_tween: _carte_tween.kill()
    if avatar_ctrl: avatar_ctrl.queue_redraw()
    if bg_ctrl: bg_ctrl.queue_redraw()


func _pulse_carte() -> void:
    if _carte_tween: _carte_tween.kill()
    _carte_tween = create_tween().set_loops()
    _carte_tween.tween_property(carte_badge, "modulate:a", 0.25, 0.5)
    _carte_tween.tween_property(carte_badge, "modulate:a", 1.0, 0.5)


func _start_pulse() -> void:
    if _pulse_tween: _pulse_tween.kill()
    _pulse_tween = create_tween().set_loops()
    var step := func(v: float):
        _pulse = v
        if avatar_ctrl: avatar_ctrl.queue_redraw()
        if bg_ctrl: bg_ctrl.queue_redraw()
    _pulse_tween.tween_method(step, 0.0, 1.0, 0.9).set_trans(Tween.TRANS_SINE)
    _pulse_tween.tween_method(step, 1.0, 0.0, 0.9).set_trans(Tween.TRANS_SINE)


func _stop_pulse() -> void:
    if _pulse_tween:
        _pulse_tween.kill()
        _pulse_tween = null
    _pulse = 0.0


func _draw_bg() -> void:
    var sz := bg_ctrl.size
    var rect := Rect2(Vector2.ZERO, sz)
    var bg_col: Color
    var border_col: Color
    var border_w: float

    if is_active:
        bg_col = Color(0.10, 0.26, 0.18, 0.92)
        border_col = Color(seat_color.r, seat_color.g, seat_color.b, 0.95)
        border_w = 2.5
    elif _eliminated:
        bg_col = Color(0.06, 0.10, 0.09, 0.55)
        border_col = Color(0.30, 0.30, 0.30, 0.45)
        border_w = 1.2
    else:
        bg_col = Color(0.06, 0.14, 0.10, 0.82)
        border_col = Color(0.22, 0.38, 0.30, 0.65)
        border_w = 1.5

    _draw_rounded_rect(bg_ctrl, rect, 18.0, bg_col, border_col, border_w)

    if is_active:
        var glow := Color(seat_color.r, seat_color.g, seat_color.b, 0.18 * _pulse)
        _draw_rounded_rect(bg_ctrl, rect.grow(-3.0), 16.0, glow, Color(0, 0, 0, 0), 0.0)

    # Mini-stack pour les adversaires
    if not is_self and player != null and not _eliminated:
        _draw_mini_stack(bg_ctrl, rect)


func _draw_mini_stack(c: Control, rect: Rect2) -> void:
    var n: int = player.hand_size()
    if n <= 0: return
    var visible_n: int = mini(n, 5)
    var card_w: float = 22.0
    var card_h: float = 30.0
    var step: float = 6.0
    var total_w: float = card_w + step * float(visible_n - 1)
    var origin := Vector2(rect.position.x + rect.size.x / 2.0 - total_w / 2.0,
                          rect.position.y + rect.size.y - card_h - 8.0)
    for i in visible_n:
        var r := Rect2(origin + Vector2(step * float(i), -float(i) * 0.8), Vector2(card_w, card_h))
        _draw_rounded_rect(c, r.grow_individual(0, 0, 0, 0).grow(0), 3.0,
                           Color(0.12, 0.18, 0.45), Color(0.4, 0.5, 0.85, 0.7), 1.0)


func _draw_avatar() -> void:
    var sz := avatar_ctrl.size
    var center := sz / 2.0
    var outer_r: float = min(sz.x, sz.y) / 2.0 - 5.0
    var inner_r: float = outer_r - 4.0

    # Couleur effective selon l'état (fire/block override seat_color)
    var halo_color: Color = seat_color
    var force_pulse: bool = false
    if seat_state == "fire":
        halo_color = FIRE_HALO
        force_pulse = true
    elif seat_state == "block":
        halo_color = BLOCK_HALO
        force_pulse = true

    # Halo pulsant quand actif OU sous effet
    var pulse_amt: float = _pulse if (is_active or force_pulse) else 0.0
    if is_active or force_pulse:
        var halo_r: float = outer_r + 5.0 + pulse_amt * 5.0
        var halo := Color(halo_color.r, halo_color.g, halo_color.b, 0.40 * (0.5 + 0.5 * pulse_amt))
        avatar_ctrl.draw_circle(center, halo_r, halo)

    # Disque de fond
    var fill: Color
    if _eliminated:
        fill = Color(0.30, 0.30, 0.30)
    elif is_active:
        fill = halo_color.lerp(Color.WHITE, 0.10)
    elif force_pulse:
        fill = halo_color.lerp(Color.WHITE, 0.05)
    else:
        fill = seat_color.darkened(0.45)
    avatar_ctrl.draw_circle(center, inner_r, fill)

    # Anneau
    var ring_col: Color
    if _eliminated:
        ring_col = Color(0.5, 0.5, 0.5, 0.6)
    elif is_active or force_pulse:
        ring_col = Color(1.0, 1.0, 1.0, 0.95)
    else:
        ring_col = Color(seat_color.r, seat_color.g, seat_color.b, 0.55)
    avatar_ctrl.draw_arc(center, outer_r - 1.0, 0.0, TAU, 56, ring_col, 3.5, true)

    # Timer arc (déplétion sens horaire depuis le haut) — uniquement en état normal
    if is_active and _timer_ratio > 0.0 and seat_state == "normal":
        var arc_col: Color
        if _timer_ratio > 0.5:
            arc_col = Color(0.30, 1.00, 0.55, 0.95)
        elif _timer_ratio > 0.25:
            arc_col = Color(1.00, 0.78, 0.18, 0.95)
        else:
            arc_col = Color(1.00, 0.30, 0.22, 0.98)
        var start_a: float = -PI / 2.0
        var end_a: float = start_a + TAU * _timer_ratio
        avatar_ctrl.draw_arc(center, outer_r + 4.0, start_a, end_a, 56, arc_col, 4.0, true)
    # Anneau d'état permanent sous feu/bloc
    elif force_pulse:
        avatar_ctrl.draw_arc(center, outer_r + 4.0, 0.0, TAU, 56,
                             Color(halo_color.r, halo_color.g, halo_color.b, 0.85), 4.0, true)

    # Image d'avatar si dispo, sinon initiales/IA
    var avatar_tex: Texture2D = null
    if player != null:
        var av_idx: int = player.id
        if is_self and has_node("/root/Profile"):
            av_idx = Profile.avatar_index
        avatar_tex = CardAssets.avatar_texture(av_idx)
    if avatar_tex != null:
        var side: float = inner_r * 2.0
        var rect := Rect2(center - Vector2(side, side) / 2.0, Vector2(side, side))
        avatar_ctrl.draw_texture_rect(avatar_tex, rect, false)
    elif player != null:
        var disp: String
        if player.is_ai:
            disp = "IA"
        else:
            var parts := player.name.split(" ")
            if parts.size() >= 2 and not parts[1].is_empty():
                disp = parts[0].left(1).to_upper() + parts[1].left(1).to_upper()
            else:
                disp = player.name.left(2).to_upper()
        var f := ThemeDB.fallback_font
        var fs: int = 24 if is_self else 20
        var ts := f.get_string_size(disp, HORIZONTAL_ALIGNMENT_CENTER, -1, fs)
        var text_col: Color = Color(0.08, 0.10, 0.08, 0.95) if is_active else Color(0.95, 0.95, 0.88, 0.88)
        avatar_ctrl.draw_string(f, center - ts / 2.0 + Vector2(0, ts.y / 3.0), disp,
                                HORIZONTAL_ALIGNMENT_CENTER, -1, fs, text_col)

    # Croix éliminé
    if _eliminated:
        var d: float = inner_r * 0.55
        avatar_ctrl.draw_line(center + Vector2(-d, -d), center + Vector2(d, d),
                              Color(1.0, 0.25, 0.20, 0.85), 3.0, true)
        avatar_ctrl.draw_line(center + Vector2(-d, d), center + Vector2(d, -d),
                              Color(1.0, 0.25, 0.20, 0.85), 3.0, true)


func _draw_rounded_rect(c: Control, rect: Rect2, r: float, fill: Color, border: Color, bw: float) -> void:
    var pts := PackedVector2Array()
    var corners := [
        Vector2(rect.position.x + r, rect.position.y + r),
        Vector2(rect.position.x + rect.size.x - r, rect.position.y + r),
        Vector2(rect.position.x + rect.size.x - r, rect.position.y + rect.size.y - r),
        Vector2(rect.position.x + r, rect.position.y + rect.size.y - r),
    ]
    var starts := [PI, -PI / 2.0, 0.0, PI / 2.0]
    for i in 4:
        for s in 7:
            var t: float = starts[i] + (PI / 2.0) * (float(s) / 6.0)
            pts.append(corners[i] + Vector2(cos(t), sin(t)) * r)
    if fill.a > 0.0:
        c.draw_colored_polygon(pts, fill)
    if bw > 0.0 and border.a > 0.0:
        var line := pts.duplicate()
        line.append(line[0])
        c.draw_polyline(line, border, bw, true)
