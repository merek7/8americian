class_name CardAssets extends RefCounted
## Cache de textures pour les figures et le dos de carte. Fallback transparent si absent.

const ASSETS_DIR := "res://assets/cards/"

static var _cache: Dictionary = {}
static var _missing: Dictionary = {}


static func face_texture(card: Card) -> Texture2D:
    if card == null: return null
    var name: String = _name_for(card)
    if name.is_empty(): return null
    return _load(name)


static func back_texture() -> Texture2D:
    return _load("back")


static func avatar_texture(seat_index: int) -> Texture2D:
    return _load("avatar_%02d" % ((seat_index % 6) + 1))


static func direction_coin_texture() -> Texture2D:
    return _load("direction_coin")


static func _name_for(card: Card) -> String:
    if card.is_joker():
        return "joker"
    var v_name: String = ""
    match card.value:
        11: v_name = "jack"
        12: v_name = "queen"
        13: v_name = "king"
        _: return ""
    var s_name: String = ""
    match card.suit:
        Card.Suit.HEART: s_name = "heart"
        Card.Suit.DIAMOND: s_name = "diamond"
        Card.Suit.CLUB: s_name = "club"
        Card.Suit.SPADE: s_name = "spade"
        _: return ""
    return "%s_%s" % [v_name, s_name]


static func _load(name: String) -> Texture2D:
    if _cache.has(name): return _cache[name]
    if _missing.has(name): return null
    var path := ASSETS_DIR + name + ".png"
    if not ResourceLoader.exists(path):
        _missing[name] = true
        return null
    var tex: Texture2D = load(path)
    _cache[name] = tex
    return tex
