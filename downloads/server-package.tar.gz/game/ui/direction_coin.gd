class_name DirectionCoin extends Control
## Pièce verte/or qui tourne en continu, sens dépend de la direction du jeu.

@export var coin_size: float = 84.0

var direction: int = 1
var _spin_speed: float = TAU / 3.2  # un tour toutes les ~3.2 s


func _ready() -> void:
    custom_minimum_size = Vector2(coin_size, coin_size)
    pivot_offset = Vector2(coin_size / 2.0, coin_size / 2.0)


func _process(delta: float) -> void:
    rotation = wrapf(rotation + float(direction) * _spin_speed * delta, -TAU * 4.0, TAU * 4.0)


func set_direction(d: int) -> void:
    direction = 1 if d >= 0 else -1


func _draw() -> void:
    var sz := size if size != Vector2.ZERO else custom_minimum_size
    var center := sz / 2.0
    var r: float = min(sz.x, sz.y) / 2.0 - 3.0

    # Asset PNG si dispo, sinon procédural
    var tex: Texture2D = CardAssets.direction_coin_texture()
    if tex != null:
        draw_circle(center + Vector2(2.0, 3.0), r, Color(0, 0, 0, 0.40))
        var side: float = r * 2.0
        draw_texture_rect(tex, Rect2(center - Vector2(side, side) / 2.0, Vector2(side, side)), false)
        return

    # Ombre portée
    draw_circle(center + Vector2(2.0, 3.0), r, Color(0, 0, 0, 0.40))
    # Disque vert profond
    draw_circle(center, r, Color(0.08, 0.40, 0.22))
    # Highlight haut
    draw_circle(center + Vector2(0, -r * 0.25), r * 0.85, Color(0.14, 0.52, 0.30, 0.55))
    # Bord doré épais
    draw_arc(center, r - 1.5, 0.0, TAU, 56, Color(1.0, 0.92, 0.45), 3.0, true)
    # Anneau intérieur or fin
    draw_arc(center, r * 0.72, 0.0, TAU, 40, Color(1.0, 0.92, 0.45, 0.55), 1.5, true)

    # 2 flèches courbes opposées (180°)
    var arrow_r: float = r * 0.55
    var gold := Color(1.0, 0.92, 0.45)
    for k in 2:
        var base_angle: float = PI * float(k)
        var arc_span: float = PI * 0.55
        var samples := 14
        var pts := PackedVector2Array()
        for i in samples + 1:
            var t := float(i) / float(samples)
            var a := base_angle - arc_span / 2.0 + t * arc_span
            pts.append(center + Vector2(cos(a), sin(a)) * arrow_r)
        draw_polyline(pts, gold, 3.5, true)
        # Tête de flèche
        var tip_a: float = base_angle + arc_span / 2.0
        var tip := center + Vector2(cos(tip_a), sin(tip_a)) * arrow_r
        var tan_dir := Vector2(-sin(tip_a), cos(tip_a))
        var bk := tip - tan_dir * 9.0
        var perp := Vector2(-tan_dir.y, tan_dir.x) * 6.0
        draw_colored_polygon(PackedVector2Array([tip, bk + perp, bk - perp]), gold)
