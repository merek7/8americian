extends Control

const CardViewScript = preload("res://ui/card_view.gd")

@onready var title_label: Label = $Panel/V/Title
@onready var body_label: RichTextLabel = $Panel/V/Body
@onready var cards_row: HBoxContainer = $Panel/V/CardsRow
@onready var prev_button: Button = $Panel/V/Buttons/Prev
@onready var next_button: Button = $Panel/V/Buttons/Next
@onready var skip_button: Button = $TopRight/Skip
@onready var page_label: Label = $Panel/V/Buttons/PageLabel

var page: int = 0
var pages: Array = []


func _ready() -> void:
    _build_pages()
    prev_button.pressed.connect(func(): _go(page - 1))
    next_button.pressed.connect(_on_next)
    skip_button.pressed.connect(_finish)
    _show_page()


func _build_pages() -> void:
    pages = [
        {
            "title": "Bienvenue dans le 8 American — Version Togolaise",
            "body": "Ce jeu de cartes stratégique se joue à [b]2 à 10 joueurs[/b].\n\n"
                + "[b]Objectif :[/b] être le premier à n'avoir [b]plus aucune carte[/b] en main.\n\n"
                + "Mais attention — chaque manche perdue rapporte des [color=#ffa]points négatifs[/color]. "
                + "Le premier à atteindre le score cible est [color=red]éliminé[/color] !",
            "cards": []
        },
        {
            "title": "Règles de base",
            "body": "À ton tour, tu poses une carte qui correspond à la précédente :\n\n"
                + "• Même [b]enseigne[/b] (♥ ♦ ♣ ♠), OU\n"
                + "• Même [b]valeur[/b]\n\n"
                + "Si tu ne peux pas jouer → tu [b]pioches 1 carte[/b].",
            "cards": [{"v": 7, "s": 0}, {"v": 7, "s": 2}, {"v": 9, "s": 2}]
        },
        {
            "title": "Le 8 — universel et bloqueur",
            "body": "Le [b]8[/b] peut être joué [b]sur n'importe quelle carte[/b].\n\n"
                + "Quand tu poses un 8, tu choisis une [b]enseigne[/b] que le suivant doit jouer.\n\n"
                + "Le 8 [b]éteint aussi toutes les sanctions[/b] (feu, joker).\n\n"
                + "[color=#ff8]Bonus :[/color] le [b]8 de pique[/b] est le seul à pouvoir éteindre un feu de 2 de pique.",
            "cards": [{"v": 8, "s": 0}, {"v": 8, "s": 1}, {"v": 8, "s": 3}]
        },
        {
            "title": "Le feu — As et 2",
            "body": "[b]As[/b] : le suivant pioche [b]1 carte[/b].\n"
                + "[b]2[/b] (hors pique) : suivant +2, J+2 +1.\n"
                + "[b]2 de pique[/b] : suivant [color=red]+4[/color], J+2 +2, J+3 +1.\n\n"
                + "Tu peux [b]éteindre[/b] le feu en jouant : un autre 2/As, un 8, ou un Joker.",
            "cards": [{"v": 1, "s": 0}, {"v": 2, "s": 1}, {"v": 2, "s": 3}]
        },
        {
            "title": "Le Joker — glisseur",
            "body": "Le [b]Joker[/b] se joue à [b]n'importe quel moment[/b].\n\n"
                + "Sous sanction, il [b]transfère le feu[/b] au joueur suivant. Plusieurs Jokers à la suite font tourner la sanction.\n\n"
                + "Hors sanction, c'est une [b]carte universelle[/b] sans effet — il glisse sous la pile et n'change pas la carte de référence.",
            "cards": [{"v": 0, "s": 4}]
        },
        {
            "title": "Le 7 — rejouer",
            "body": "Quand tu joues un [b]7[/b], tu [b]rejoues une carte[/b] immédiatement.\n\n"
                + "Tu peux enchaîner plusieurs 7. La carte finale de la chaîne peut être spéciale.\n\n"
                + "[color=#fa6]Attention :[/color] tu [b]ne peux pas finir[/b] la manche avec un 7 — tu pioches une carte à la place.",
            "cards": [{"v": 7, "s": 0}, {"v": 7, "s": 1}, {"v": 5, "s": 1}]
        },
        {
            "title": "Le Valet — saut",
            "body": "[b]Valet[/b] : saute le joueur suivant.\n"
                + "[b]Valet de pique[/b] : saute [b]2 joueurs[/b].\n\n"
                + "À 2 joueurs : un Valet te fait rejouer ; un Valet de pique passe le tour à l'adversaire (saute toi + lui).",
            "cards": [{"v": 11, "s": 0}, {"v": 11, "s": 3}]
        },
        {
            "title": "Le 10 — inversion",
            "body": "Le [b]10[/b] inverse le sens du jeu.\n\n"
                + "Plusieurs 10 successifs s'annulent (chaque 10 inverse une fois).\n\n"
                + "À 2 joueurs, le 10 n'a [b]aucun effet[/b] (le sens n'a pas de signification).",
            "cards": [{"v": 10, "s": 0}, {"v": 10, "s": 2}]
        },
        {
            "title": "Annonce \"CARTE\"",
            "body": "Quand tu vas jouer ton [b]avant-dernière[/b] carte, tu dois cliquer le bouton [b]CARTE[/b] avant.\n\n"
                + "Si tu oublies → [color=red]+4 cartes[/color] de pénalité, applicable même rétroactivement.\n\n"
                + "Si tu cries CARTE en jouant un 7 (ton avant-dernière) → [b]+1 carte[/b].",
            "cards": []
        },
        {
            "title": "Système de score",
            "body": "À la fin d'une manche, les cartes restantes en main donnent des points :\n\n"
                + "• As, Dame, Roi : 1 point\n"
                + "• 2-7 : leur valeur\n"
                + "• 2 de pique : 4   •   8 : 32   •   [color=red]8 de pique : 64[/color]\n"
                + "• Valet : 11   •   Valet de pique : 22\n"
                + "• Joker : 50\n\n"
                + "Le premier à atteindre [b]50 ou 100 points[/b] (selon config) est éliminé.",
            "cards": []
        },
        {
            "title": "Tu es prêt !",
            "body": "Lance une partie [b]Solo vs IA[/b] depuis le menu pour pratiquer.\n\n"
                + "Pour les modes multijoueur :\n"
                + "• [b]Local[/b] : passez-vous l'écran à chaque tour\n"
                + "• [b]En ligne[/b] : héberge ou rejoins une partie via IP\n\n"
                + "Bonne partie !",
            "cards": []
        }
    ]


func _show_page() -> void:
    var p: Dictionary = pages[page]
    title_label.text = p["title"]
    body_label.text = p["body"]
    page_label.text = "%d / %d" % [page + 1, pages.size()]

    for c in cards_row.get_children():
        cards_row.remove_child(c)
        c.queue_free()
    var cards: Array = p.get("cards", [])
    for cd in cards:
        var cv := Control.new()
        cv.set_script(CardViewScript)
        cards_row.add_child(cv)
        var card := Card.create(cd.get("v", 0), cd.get("s", 0))
        cv.setup(card, false)
        cv.set_playable(true)

    prev_button.disabled = (page == 0)
    next_button.text = "Terminer" if page == pages.size() - 1 else "Suivant"

    title_label.modulate.a = 0.0
    body_label.modulate.a = 0.0
    cards_row.modulate.a = 0.0
    var tw := create_tween().set_parallel(true)
    tw.tween_property(title_label, "modulate:a", 1.0, 0.25)
    tw.tween_property(body_label, "modulate:a", 1.0, 0.35)
    tw.tween_property(cards_row, "modulate:a", 1.0, 0.4)


func _go(p: int) -> void:
    page = clampi(p, 0, pages.size() - 1)
    if has_node("/root/SoundFX"): SoundFX.play(&"click")
    _show_page()


func _on_next() -> void:
    if page == pages.size() - 1:
        _finish()
    else:
        _go(page + 1)


func _finish() -> void:
    if has_node("/root/SoundFX"): SoundFX.play(&"click")
    if has_node("/root/Profile"):
        Profile.tutorial_done = true
        Profile.save_profile()
    var tw := create_tween()
    tw.tween_property(self, "modulate:a", 0.0, 0.2)
    tw.tween_callback(func(): get_tree().change_scene_to_file("res://ui/main_menu.tscn"))
