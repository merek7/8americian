class_name BlockEffect extends EffectBase
## RG-EFF-05 / RG-EFF-06 : 8 et 8♠.
## Mode 1 : éteint sanction. Mode 2 : carte normale.
## Toujours : impose une enseigne au suivant.
## chosen_suit doit être renseigné AVANT apply() via set_chosen_suit().

var chosen_suit: int = -1


func set_chosen_suit(suit: int) -> void:
    chosen_suit = suit


func apply(_card: Card, state: GameState) -> EffectResult:
    # Éteint toute sanction active (le 8 ignore tout).
    state.active_fire = null
    state.active_transfer = null
    state.required_suit = chosen_suit

    var r := EffectResult.new()
    r.message = "8 joué — enseigne imposée: %d" % chosen_suit
    return r
