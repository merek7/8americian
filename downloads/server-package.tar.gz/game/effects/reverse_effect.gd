class_name ReverseEffect extends EffectBase
## RG-EFF-11 : 10 — inverse le sens. Plusieurs 10 s'annulent (chaque 10 inverse).

func apply(_card: Card, state: GameState) -> EffectResult:
    var r := EffectResult.new()

    # En 1v1, le sens n'a aucune signification — le 10 est neutre.
    if state.active_players_count() == 2:
        r.message = "10 — sans effet (1v1)"
        return r

    state.direction *= -1
    r.message = "Sens inversé (direction=%d)" % state.direction
    return r
