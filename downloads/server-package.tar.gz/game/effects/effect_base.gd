class_name EffectBase extends RefCounted
## Interface commune pour tous les effets. Strategy pattern (Open/Closed).

class EffectResult extends RefCounted:
    var success: bool = true
    var message: String = ""
    var should_skip_advance: bool = false  # si true, ne pas passer au joueur suivant auto


func can_apply(_card: Card, _state: GameState) -> bool:
    return true


func apply(_card: Card, _state: GameState) -> EffectResult:
    push_error("Override apply() in subclass")
    var r := EffectResult.new()
    r.success = false
    return r
