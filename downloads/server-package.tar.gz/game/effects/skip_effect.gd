class_name SkipEffect extends EffectBase
## RG-EFF-09 / RG-EFF-10 : Valet (saute 1) / Valet♠ (saute 2).

func apply(card: Card, state: GameState) -> EffectResult:
    var skips: int = 2 if card.suit == Card.Suit.SPADE else 1
    # next_player_idx avance dans un cycle modulo nb_actifs.
    # En 1v1 : skips=1 → avance 2 = retour à soi ✓ ; skips=2 → avance 3 = adversaire ✓.
    state.pending_skip = skips

    var r := EffectResult.new()
    r.message = "Saut de %d joueur(s)" % skips
    return r
