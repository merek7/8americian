class_name ReplayEffect extends EffectBase
## RG-EFF-08 : 7 — rejouer. Force le joueur courant à rejouer une carte.

func apply(_card: Card, state: GameState) -> EffectResult:
    state.must_replay = true
    state.replay_chain += 1

    var r := EffectResult.new()
    r.should_skip_advance = true
    r.message = "7 joué — rejouer (chaîne: %d)" % state.replay_chain
    return r
