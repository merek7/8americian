class_name FireEffect extends EffectBase
## RG-EFF-01 à RG-EFF-04 : feu (As, As♠, 2, 2♠).

func apply(card: Card, state: GameState) -> EffectResult:
    var fire := GameState.FireSanction.new()
    fire.source_card = card
    fire.damage_queue = _build_queue(card)
    state.active_fire = fire

    var r := EffectResult.new()
    r.message = "Feu actif (%s) — file de dégâts: %s" % [card.to_string_short(), str(fire.damage_queue)]
    return r


static func _build_queue(card: Card) -> Array[int]:
    var is_spade: bool = card.suit == Card.Suit.SPADE
    if card.value == 1:
        return [1]                          # As / As♠
    if card.value == 2 and is_spade:
        return [4, 2, 1]                    # 2♠
    if card.value == 2:
        return [2, 1]                       # 2 (non-pique)
    return []
