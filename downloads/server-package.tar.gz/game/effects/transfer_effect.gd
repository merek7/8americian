class_name TransferEffect extends EffectBase
## RG-EFF-07 : Joker — glisseur. Transfère sanction OU carte universelle sans effet.
## Spécificité H-02 : Joker placé SOUS la pile, top_reference inchangé.

func apply(_card: Card, state: GameState) -> EffectResult:
    var r := EffectResult.new()

    if state.active_fire != null:
        var t := GameState.TransferSanction.new()
        t.origin_fire = state.active_fire
        t.hops = 1
        state.active_transfer = t
        state.active_fire = null
        r.message = "Joker — feu transféré"
        return r

    if state.active_transfer != null:
        state.active_transfer.hops += 1
        r.message = "Joker — transfert continué (%d hops)" % state.active_transfer.hops
        return r

    # Pas de sanction active : Joker sans effet (carte universelle).
    r.message = "Joker — carte universelle (pas d'effet)"
    return r
