class_name TurnManager extends RefCounted
## Gère l'avancée des tours, sauts et inversions.
## La direction et current_player_idx vivent dans GameState ; ce manager opère dessus.

signal turn_changed(player_id: int)


func advance(state: GameState) -> void:
    var skips: int = max(1, 1 + state.pending_skip)
    state.pending_skip = 0
    state.current_player_idx = state.next_player_idx(skips)
    turn_changed.emit(state.current_player().id)


func reverse(state: GameState) -> void:
    state.direction *= -1


func skip(state: GameState, n: int) -> void:
    state.pending_skip += n
