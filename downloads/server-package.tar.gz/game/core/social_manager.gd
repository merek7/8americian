extends Node
## Gère les messages de chat et les réactions de manière globale.
## Compatible avec le mode Solo (IA), Local et En Ligne (RPC).

signal message_received(sender_name: String, text: String, color: Color)
signal reaction_received(player_id: int, emoji: String)

const MAX_CHAT_HISTORY = 50
var chat_history: Array = []

func _ready() -> void:
    # S'assurer que le NetworkManager peut relayer nos messages
    if has_node("/root/NetworkManager"):
        get_node("/root/NetworkManager").reaction_triggered.connect(_on_network_reaction)
        get_node("/root/NetworkManager").chat_triggered.connect(_on_network_chat)

## Envoyer un message de chat
func send_chat(text: String) -> void:
    if NetworkManager.is_online:
        NetworkManager.send_chat_message(text)
    else:
        # En local, on l'affiche directement
        add_message("Moi", text, Color.SKY_BLUE)
        # Petit clin d'œil de l'IA si on dit bonjour
        if GameManager.state != null and text.to_lower().contains("bonjour"):
            add_message("Système", "L'IA vous salue !", Color.GRAY)

## Envoyer une réaction
func send_reaction(emoji: String) -> void:
    if NetworkManager.is_online:
        var pid = NetworkManager.local_player_id
        NetworkManager.send_reaction(pid, emoji)
    else:
        # En local, on déclenche le signal immédiatement
        # On utilise le pid 0 pour le joueur local en mode solo
        emit_signal("reaction_received", 0, emoji)

## Ajouter un message à l'historique local
func add_message(sender: String, text: String, color: Color = Color.WHITE) -> void:
    var msg = {"sender": sender, "text": text, "color": color, "time": Time.get_time_string_from_system()}
    chat_history.append(msg)
    if chat_history.size() > MAX_CHAT_HISTORY:
        chat_history.pop_front()
    
    emit_signal("message_received", sender, text, color)

# --- Callbacks réseau ---

func _on_network_chat(sender_name: String, text: String) -> void:
    add_message(sender_name, text, Color.WHITE)

func _on_network_reaction(player_id: int, emoji: String) -> void:
    emit_signal("reaction_received", player_id, emoji)
