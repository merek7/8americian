extends Node
## Profil joueur sauvegardé sur disque (user://profile.json).

signal profile_changed()

const PATH := "user://profile.json"

const AVATAR_COLORS := [
    Color(0.95, 0.85, 0.25),
    Color(0.55, 0.85, 0.35),
    Color(0.35, 0.75, 0.95),
    Color(0.95, 0.45, 0.55),
    Color(0.85, 0.45, 0.95),
    Color(0.95, 0.65, 0.30),
]

var pseudo: String = "Joueur"
var avatar_index: int = 0
var games_played: int = 0
var games_won: int = 0
var ai_difficulty: String = "basic"
var tutorial_done: bool = false
var felt_choice: int = 0

# Stats détaillées
var stats_per_diff: Dictionary = {
    "basic": {"played": 0, "won": 0},
    "medium": {"played": 0, "won": 0},
    "hard": {"played": 0, "won": 0},
}
var current_streak: int = 0
var longest_streak: int = 0
var best_score: int = -1  # -1 = jamais
var total_local_games: int = 0
var total_online_games: int = 0
var tournaments_played: int = 0
var tournaments_won: int = 0


func _ready() -> void:
    load_profile()


func load_profile() -> void:
    if not FileAccess.file_exists(PATH):
        return
    var f := FileAccess.open(PATH, FileAccess.READ)
    if f == null: return
    var txt := f.get_as_text()
    f.close()
    var data = JSON.parse_string(txt)
    if typeof(data) != TYPE_DICTIONARY: return
    pseudo = data.get("pseudo", "Joueur")
    avatar_index = clampi(data.get("avatar_index", 0), 0, AVATAR_COLORS.size() - 1)
    games_played = data.get("games_played", 0)
    games_won = data.get("games_won", 0)
    ai_difficulty = data.get("ai_difficulty", "basic")
    tutorial_done = data.get("tutorial_done", false)
    felt_choice = data.get("felt_choice", 0)
    var sp: Dictionary = data.get("stats_per_diff", {})
    for k in stats_per_diff.keys():
        if sp.has(k): stats_per_diff[k] = sp[k]
    current_streak = data.get("current_streak", 0)
    longest_streak = data.get("longest_streak", 0)
    best_score = data.get("best_score", -1)
    total_local_games = data.get("total_local_games", 0)
    total_online_games = data.get("total_online_games", 0)
    tournaments_played = data.get("tournaments_played", 0)
    tournaments_won = data.get("tournaments_won", 0)


func save_profile() -> void:
    var data := {
        "pseudo": pseudo,
        "avatar_index": avatar_index,
        "games_played": games_played,
        "games_won": games_won,
        "ai_difficulty": ai_difficulty,
        "tutorial_done": tutorial_done,
        "felt_choice": felt_choice,
        "stats_per_diff": stats_per_diff,
        "current_streak": current_streak,
        "longest_streak": longest_streak,
        "best_score": best_score,
        "total_local_games": total_local_games,
        "total_online_games": total_online_games,
        "tournaments_played": tournaments_played,
        "tournaments_won": tournaments_won,
    }
    var f := FileAccess.open(PATH, FileAccess.WRITE)
    if f == null: return
    f.store_string(JSON.stringify(data, "  "))
    f.close()


func set_pseudo(new_pseudo: String) -> void:
    pseudo = new_pseudo.strip_edges()
    if pseudo.is_empty(): pseudo = "Joueur"
    save_profile()
    emit_signal("profile_changed")


func set_avatar_index(idx: int) -> void:
    avatar_index = clampi(idx, 0, AVATAR_COLORS.size() - 1)
    save_profile()
    emit_signal("profile_changed")


func avatar_color() -> Color:
    return AVATAR_COLORS[avatar_index]


func set_felt_choice(idx: int) -> void:
    felt_choice = clampi(idx, 0, 4)
    save_profile()
    emit_signal("profile_changed")


func record_game(won: bool) -> void:
    games_played += 1
    if won: games_won += 1
    save_profile()


func record_game_detailed(won: bool, ai_diff: String, end_score: int, online: bool) -> void:
    games_played += 1
    if won: games_won += 1
    if stats_per_diff.has(ai_diff):
        stats_per_diff[ai_diff]["played"] = int(stats_per_diff[ai_diff]["played"]) + 1
        if won:
            stats_per_diff[ai_diff]["won"] = int(stats_per_diff[ai_diff]["won"]) + 1
    if won:
        current_streak += 1
        if current_streak > longest_streak:
            longest_streak = current_streak
    else:
        current_streak = 0
    if won and end_score >= 0:
        if best_score < 0 or end_score < best_score:
            best_score = end_score
    if online:
        total_online_games += 1
    else:
        total_local_games += 1
    save_profile()
    emit_signal("profile_changed")


func record_tournament(won: bool) -> void:
    tournaments_played += 1
    if won: tournaments_won += 1
    save_profile()
    emit_signal("profile_changed")


func win_rate(diff: String) -> float:
    if not stats_per_diff.has(diff): return 0.0
    var p: int = int(stats_per_diff[diff]["played"])
    if p <= 0: return 0.0
    return float(stats_per_diff[diff]["won"]) / float(p)
