extends Node
## Gestion multijoueur ENet. Host autoritaire, clients consomment l'état.
## Limite : 10 joueurs total par partie.

signal lobby_updated(players: Array)
signal connected_to_host()
signal disconnected_from_host()
signal connection_failed(reason: String)
signal state_received(state_dict: Dictionary)
signal log_message(msg: String)
signal chat_triggered(sender_name: String, text: String)
signal reaction_triggered(player_id: int, emoji: String)
signal pings_updated(pings_by_pid: Dictionary)
signal player_disconnected_mid_game(player_name: String, player_id: int)

const MAX_CLIENTS := 10
const DEFAULT_PORT := 9080
const MAX_NAME_LENGTH := 32
const MAX_PASSWORD_LENGTH := 64
const RATE_LIMIT_WINDOW_MS := 1000
const RATE_LIMIT_MAX := 30

var is_online: bool = false
var is_host: bool = false
var is_dedicated: bool = false      # serveur dédié sans joueur local
var local_peer_id: int = 0
var local_player_id: int = -1
var lobby_players: Dictionary = {}
var pending_name: String = "Joueur"
var pending_password: String = ""
var server_password: String = ""    # côté hôte uniquement
var _rpc_history: Dictionary = {}   # peer_id -> Array[int] timestamps ms
var pings_by_pid: Dictionary = {}   # player_id -> ping ms (mis à jour côté hôte, propagé)
var _ping_accum: float = 0.0
const PING_INTERVAL := 2.0


func _ready() -> void:
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    multiplayer.connected_to_server.connect(_on_connected_ok)
    multiplayer.connection_failed.connect(_on_connection_failed)
    multiplayer.server_disconnected.connect(_on_server_disconnect)
    set_process(true)


func _process(delta: float) -> void:
    if not (is_online and is_host): return
    _ping_accum += delta
    if _ping_accum < PING_INTERVAL: return
    _ping_accum = 0.0
    _measure_and_broadcast_pings()


func _measure_and_broadcast_pings() -> void:
    var enet := multiplayer.multiplayer_peer as ENetMultiplayerPeer
    if enet == null: return
    var new_pings: Dictionary = {}
    for peer_id in lobby_players:
        var info: Dictionary = lobby_players[peer_id]
        var pid: int = info.get("player_id", -1)
        if pid < 0: continue
        if peer_id == 1:
            new_pings[pid] = 0
        else:
            var ppeer: ENetPacketPeer = enet.get_peer(peer_id)
            if ppeer != null:
                new_pings[pid] = int(ppeer.get_statistic(ENetPacketPeer.PEER_ROUND_TRIP_TIME))
    pings_by_pid = new_pings
    emit_signal("pings_updated", new_pings)
    if not is_dedicated:
        # Diffuse aux autres clients
        _push_pings.rpc(new_pings)
    else:
        _push_pings.rpc(new_pings)


@rpc("authority", "reliable")
func _push_pings(pings: Dictionary) -> void:
    pings_by_pid = pings
    emit_signal("pings_updated", pings)


# ─── Host / Join ───────────────────────────────────────────────────────────────

func host_game(port: int, host_name: String, password: String = "") -> bool:
    var peer := ENetMultiplayerPeer.new()
    var err := peer.create_server(port, MAX_CLIENTS)
    if err != OK:
        emit_signal("connection_failed", "Erreur hôte: %s" % str(err))
        return false
    multiplayer.multiplayer_peer = peer
    is_online = true
    is_host = true
    is_dedicated = false
    local_peer_id = 1
    pending_name = _sanitize_name(host_name)
    server_password = password.left(MAX_PASSWORD_LENGTH)
    lobby_players.clear()
    lobby_players[1] = {"name": pending_name, "player_id": 0, "ready": true, "is_host": true}
    _hook_host_event_relay()
    emit_signal("lobby_updated", _lobby_array())
    var pw_note: String = "  (mot de passe activé)" if server_password != "" else ""
    emit_signal("log_message", "Hôte démarré sur le port %d%s" % [port, pw_note])
    return true


func start_dedicated_server(port: int, password: String = "") -> bool:
    var peer := ENetMultiplayerPeer.new()
    var err := peer.create_server(port, MAX_CLIENTS)
    if err != OK:
        push_error("Échec démarrage serveur dédié: %s" % str(err))
        return false
    multiplayer.multiplayer_peer = peer
    is_online = true
    is_host = true
    is_dedicated = true
    local_peer_id = 1
    server_password = password.left(MAX_PASSWORD_LENGTH)
    lobby_players.clear()
    _hook_host_event_relay()
    var pw_note: String = " (mot de passe activé)" if server_password != "" else " (sans mot de passe)"
    print("[Server] Serveur dédié sur port %d (max %d clients)%s" % [port, MAX_CLIENTS, pw_note])
    return true


func _hook_host_event_relay() -> void:
    # Relai les events du GameManager local vers les clients en payload sérialisable.
    if not GameManager.card_played.is_connected(_relay_card_played):
        GameManager.card_played.connect(_relay_card_played)
        GameManager.card_drawn.connect(_relay_card_drawn)
        GameManager.fire_landed.connect(_relay_fire)
        GameManager.effect_triggered.connect(_relay_effect)
        GameManager.round_ended.connect(_relay_round_ended)
        GameManager.game_over.connect(_relay_game_over)


func _relay_card_played(card: Card, pid: int) -> void:
    broadcast_event("card_played", {"v": card.value, "s": card.suit, "pid": pid})


func _relay_card_drawn(pid: int, count: int) -> void:
    broadcast_event("card_drawn", {"pid": pid, "count": count})


func _relay_fire(pid: int, dmg: int) -> void:
    broadcast_event("fire_landed", {"pid": pid, "dmg": dmg})


func _relay_effect(name: String, payload: Dictionary) -> void:
    broadcast_event("effect_triggered", {"name": name, "payload": payload})


func _relay_round_ended(scores: Dictionary) -> void:
    broadcast_event("round_ended", {"scores": scores})


func _relay_game_over(winner: int) -> void:
    broadcast_event("game_over", {"winner": winner})


func join_game(ip: String, port: int, name: String, password: String = "") -> bool:
    var peer := ENetMultiplayerPeer.new()
    var err := peer.create_client(ip, port)
    if err != OK:
        emit_signal("connection_failed", "Erreur connexion: %s" % str(err))
        return false
    multiplayer.multiplayer_peer = peer
    is_online = true
    is_host = false
    pending_name = _sanitize_name(name)
    pending_password = password.left(MAX_PASSWORD_LENGTH)
    return true


func leave() -> void:
    if multiplayer.multiplayer_peer:
        multiplayer.multiplayer_peer.close()
    multiplayer.multiplayer_peer = null
    is_online = false
    is_host = false
    local_peer_id = 0
    local_player_id = -1
    lobby_players.clear()


# ─── Multiplayer events ────────────────────────────────────────────────────────

func _on_peer_connected(peer_id: int) -> void:
    if is_host:
        # On attend que le client envoie son nom (RPC _client_announce)
        emit_signal("log_message", "Pair connecté: %d" % peer_id)


func _on_peer_disconnected(peer_id: int) -> void:
    if is_host and lobby_players.has(peer_id):
        var info: Dictionary = lobby_players[peer_id]
        var p_name: String = info.get("name", "Joueur")
        var p_id: int = info.get("player_id", -1)
        lobby_players.erase(peer_id)
        emit_signal("lobby_updated", _lobby_array())
        emit_signal("log_message", "Pair déconnecté: %d (%s)" % [peer_id, p_name])
        # Si une partie est en cours, on alerte tous les clients restants
        var game_in_progress: bool = (
            has_node("/root/GameManager")
            and GameManager.state != null
            and not GameManager.state.game_finished
        )
        if game_in_progress:
            emit_signal("player_disconnected_mid_game", p_name, p_id)
            broadcast_event("game_paused", {"reason": "disconnect", "name": p_name, "pid": p_id})
    _rpc_history.erase(peer_id)


func _on_connected_ok() -> void:
    local_peer_id = multiplayer.get_unique_id()
    emit_signal("connected_to_host")
    _client_announce.rpc_id(1, pending_name, pending_password)


func _on_connection_failed() -> void:
    is_online = false
    emit_signal("connection_failed", "Connexion impossible")


func _on_server_disconnect() -> void:
    is_online = false
    emit_signal("disconnected_from_host")


# ─── RPC ───────────────────────────────────────────────────────────────────────

@rpc("any_peer", "reliable")
func _client_announce(player_name: String, password: String = "") -> void:
    if not is_host: return
    var sender := multiplayer.get_remote_sender_id()
    if not _check_rate_limit(sender):
        _kick_peer(sender, "rate-limit dépassé")
        return
    # Vérification password
    if server_password != "" and password.left(MAX_PASSWORD_LENGTH) != server_password:
        _kick_peer(sender, "mot de passe invalide")
        return
    # Sanitize pseudo
    var clean_name: String = _sanitize_name(player_name)
    var pid: int = _next_free_player_id()
    lobby_players[sender] = {"name": clean_name, "player_id": pid, "ready": false, "is_host": false}
    emit_signal("lobby_updated", _lobby_array())
    emit_signal("log_message", "%s a rejoint la partie (siège %d)" % [clean_name, pid])
    if is_dedicated:
        print("[Server] %s rejoint (peer %d, siège %d)" % [clean_name, sender, pid])
    _push_lobby.rpc(_lobby_array())
    _assign_player_id.rpc_id(sender, pid)


func _next_free_player_id() -> int:
    var used: Array = []
    for p in lobby_players.values():
        used.append(p.get("player_id", -1))
    var i := 0
    while i in used:
        i += 1
    return i


@rpc("any_peer", "reliable")
func request_start_game(score_target: int) -> void:
    if not is_host: return
    if not is_dedicated:
        return  # en mode hôte-joueur, c'est le bouton local qui démarre
    var nb_players: int = lobby_players.size()
    if nb_players < 2:
        emit_signal("log_message", "Démarrage refusé : %d joueur(s) seulement" % nb_players)
        return
    var config := {
        "nb_decks": maxi(2, int(ceil(nb_players / 2.0))),
        "nb_players": nb_players,
        "cards_dealt": 5,
        "score_target": score_target,
        "mode": "online",
        "ai_difficulty": "basic"
    }
    var names: Array = []
    var sorted_lobby: Array = _lobby_array()
    for entry in sorted_lobby:
        names.append(entry.get("name", "Joueur"))
    GameManager.start_game(config, names)
    emit_signal("log_message", "Partie démarrée avec %d joueurs" % nb_players)


@rpc("any_peer", "reliable")
func _push_lobby(players_array: Array) -> void:
    if is_host: return
    lobby_players.clear()
    for p in players_array:
        lobby_players[p.get("peer", 0)] = p
    emit_signal("lobby_updated", players_array)


@rpc("authority", "reliable")
func _assign_player_id(pid: int) -> void:
    local_player_id = pid


@rpc("any_peer", "reliable")
func set_ready(state: bool) -> void:
    if not is_host: return
    var sender := multiplayer.get_remote_sender_id()
    if not _check_rate_limit(sender):
        _kick_peer(sender, "rate-limit dépassé")
        return
    if lobby_players.has(sender):
        lobby_players[sender]["ready"] = state
        emit_signal("lobby_updated", _lobby_array())
        _push_lobby.rpc(_lobby_array())


@rpc("any_peer", "reliable")
func request_play_card(card_data: Dictionary, context: Dictionary) -> void:
    if not is_host: return
    var sender := multiplayer.get_remote_sender_id()
    if not _check_rate_limit(sender):
        _kick_peer(sender, "rate-limit dépassé")
        return
    var info: Dictionary = lobby_players.get(sender, {})
    var pid: int = info.get("player_id", -1)
    if pid < 0 or pid != GameManager.state.current_player_idx: return
    var card := _find_card_in_hand(pid, card_data)
    if card != null:
        GameManager.player_plays_card(pid, card, context)


@rpc("any_peer", "reliable")
func request_draw() -> void:
    if not is_host: return
    var sender := multiplayer.get_remote_sender_id()
    if not _check_rate_limit(sender):
        _kick_peer(sender, "rate-limit dépassé")
        return
    var info: Dictionary = lobby_players.get(sender, {})
    var pid: int = info.get("player_id", -1)
    if pid < 0 or pid != GameManager.state.current_player_idx: return
    GameManager.player_draws(pid)


@rpc("any_peer", "reliable")
func request_continue_round() -> void:
    if not is_host: return
    var sender := multiplayer.get_remote_sender_id()
    if not _check_rate_limit(sender):
        _kick_peer(sender, "rate-limit dépassé")
        return
    # Vérifie que le sender est un joueur actif de la partie
    var info: Dictionary = lobby_players.get(sender, {})
    var pid: int = info.get("player_id", -1)
    if pid < 0:
        return
    GameManager.continue_to_next_round()


# ─── Diffusion d'état (host → clients) ─────────────────────────────────────────

func broadcast_state() -> void:
    if not is_host: return
    for peer_id in lobby_players:
        var info: Dictionary = lobby_players[peer_id]
        var pid: int = info.get("player_id", -1)
        var dict := serialize_state(pid)
        if peer_id == 1 and not is_dedicated:
            emit_signal("state_received", dict)
        elif peer_id != 1:
            _receive_state.rpc_id(peer_id, dict)


signal remote_event(event_name: String, payload: Dictionary)


func broadcast_event(event_name: String, payload: Dictionary) -> void:
    if not is_host: return
    for peer_id in lobby_players:
        if peer_id == 1: continue
        _receive_event.rpc_id(peer_id, event_name, payload)


@rpc("authority", "reliable")
func _receive_state(state_dict: Dictionary) -> void:
    emit_signal("state_received", state_dict)


@rpc("authority", "reliable")
func _receive_event(event_name: String, payload: Dictionary) -> void:
    emit_signal("remote_event", event_name, payload)


# ─── Sérialisation ─────────────────────────────────────────────────────────────

func serialize_state(viewer_pid: int) -> Dictionary:
    var st: GameState = GameManager.state
    if st == null: return {}
    var players_data: Array = []
    for p in st.players:
        var hand_serialized: Array = []
        var visible_hand: bool = (p.id == viewer_pid)
        if visible_hand:
            for c in p.hand:
                hand_serialized.append(_card_to_dict(c))
        players_data.append({
            "id": p.id, "name": p.name, "score": p.score,
            "hand_size": p.hand_size(), "is_ai": p.is_ai,
            "is_eliminated": p.is_eliminated,
            "has_called_carte": p.has_called_carte,
            "hand": hand_serialized
        })
    return {
        "viewer_pid": viewer_pid,
        "players": players_data,
        "current_player_idx": st.current_player_idx,
        "direction": st.direction,
        "deck_size": st.deck.size(),
        "discard_top": _card_to_dict(st.top_reference()) if st.top_reference() else {},
        "required_suit": st.required_suit,
        "active_fire": _fire_to_dict(st.active_fire),
        "active_transfer": (st.active_transfer != null),
        "must_replay": st.must_replay,
        "replay_chain": st.replay_chain,
        "round_finished": st.round_finished,
        "game_finished": st.game_finished
    }


func _card_to_dict(c: Card) -> Dictionary:
    if c == null: return {}
    return {"v": c.value, "s": c.suit}


func _fire_to_dict(f) -> Dictionary:
    if f == null: return {}
    return {
        "src_v": f.source_card.value,
        "src_s": f.source_card.suit,
        "queue": f.damage_queue,
        "idx": f.current_damage_idx
    }


func _find_card_in_hand(pid: int, card_data: Dictionary) -> Card:
    if GameManager.state == null: return null
    var p: Player = GameManager.state.players[pid]
    for c in p.hand:
        if c.value == card_data.get("v") and c.suit == card_data.get("s"):
            return c
    return null


func _sanitize_name(raw: String) -> String:
    var s := raw.strip_edges().left(MAX_NAME_LENGTH)
    # retire les caractères de contrôle non imprimables
    var out := ""
    for c in s:
        var code := c.unicode_at(0)
        if code >= 32 and code != 127:
            out += c
    if out.is_empty(): out = "Joueur"
    return out


func _check_rate_limit(peer_id: int) -> bool:
    var now := Time.get_ticks_msec()
    if not _rpc_history.has(peer_id):
        _rpc_history[peer_id] = []
    var arr: Array = _rpc_history[peer_id]
    while arr.size() > 0 and int(arr[0]) < now - RATE_LIMIT_WINDOW_MS:
        arr.pop_front()
    arr.append(now)
    return arr.size() <= RATE_LIMIT_MAX


func _kick_peer(peer_id: int, reason: String) -> void:
    emit_signal("log_message", "Kick %d : %s" % [peer_id, reason])
    if is_dedicated:
        print("[Server] Kick peer %d : %s" % [peer_id, reason])
    if multiplayer.multiplayer_peer:
        multiplayer.multiplayer_peer.disconnect_peer(peer_id)
    lobby_players.erase(peer_id)
    _rpc_history.erase(peer_id)
    emit_signal("lobby_updated", _lobby_array())


func _lobby_array() -> Array:
    var arr := []
    for peer_id in lobby_players:
        var d: Dictionary = lobby_players[peer_id].duplicate()
        d["peer"] = peer_id
        arr.append(d)
    arr.sort_custom(func(a, b): return a.get("player_id", 0) < b.get("player_id", 0))
    return arr


# ─── Social (Chat & Reactions) ────────────────────────────────────────────────

func send_chat_message(text: String) -> void:
    var clean_text = text.strip_edges().left(128)
    if clean_text.is_empty(): return
    rpc_id(1, "_server_receive_chat", clean_text)

func send_reaction(pid: int, emoji: String) -> void:
    rpc_id(1, "_server_receive_reaction", pid, emoji)

@rpc("any_peer", "call_local", "reliable")
func _server_receive_chat(text: String) -> void:
    var peer_id = multiplayer.get_remote_sender_id()
    if not _check_rate_limit(peer_id): return
    
    var sender_name = "Inconnu"
    if lobby_players.has(peer_id):
        sender_name = lobby_players[peer_id].name
    
    var clean_text = _sanitize_name(text).left(128)
    rpc("_client_receive_chat", sender_name, clean_text)

@rpc("any_peer", "call_local", "reliable")
func _server_receive_reaction(pid: int, emoji: String) -> void:
    var peer_id = multiplayer.get_remote_sender_id()
    if not _check_rate_limit(peer_id): return
    rpc("_client_receive_reaction", pid, emoji)

@rpc("authority", "call_local", "reliable")
func _client_receive_chat(sender_name: String, text: String) -> void:
    emit_signal("chat_triggered", sender_name, text)

@rpc("authority", "call_local", "reliable")
func _client_receive_reaction(pid: int, emoji: String) -> void:
    emit_signal("reaction_triggered", pid, emoji)
