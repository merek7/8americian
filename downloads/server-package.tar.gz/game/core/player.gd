class_name Player extends Resource
## Données d'un joueur. Pas de logique de jeu ici, uniquement de l'état.

@export var id: int = 0
@export var name: String = ""
@export var hand: Array[Card] = []
@export var score: int = 0
@export var has_called_carte: bool = false
@export var is_ai: bool = false
@export var is_eliminated: bool = false
@export var ai_difficulty: String = ""  # surcharge optionnelle pour mode multi-IA


static func create(p_id: int, p_name: String, p_is_ai: bool = false) -> Player:
    var p := Player.new()
    p.id = p_id
    p.name = p_name
    p.is_ai = p_is_ai
    return p


func add_card(card: Card) -> void:
    hand.append(card)


func add_cards(cards: Array[Card]) -> void:
    hand.append_array(cards)


func remove_card(card: Card) -> bool:
    var idx := hand.find(card)
    if idx == -1:
        return false
    hand.remove_at(idx)
    return true


func hand_points() -> int:
    var total := 0
    for c in hand:
        total += c.points
    return total


func hand_size() -> int:
    return hand.size()


func is_empty() -> bool:
    return hand.is_empty()
