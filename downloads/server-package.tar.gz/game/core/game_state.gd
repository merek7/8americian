class_name GameState extends RefCounted
## État de jeu pur, sans Node UI. Manipulé par GameManager et lu par RuleValidator.

class FireSanction extends RefCounted:
    var source_card: Card
    var damage_queue: Array[int] = []  # ex: [4,2,1] pour 2♠
    var current_damage_idx: int = 0

    func current_damage() -> int:
        if current_damage_idx >= damage_queue.size():
            return 0
        return damage_queue[current_damage_idx]

    func advance() -> void:
        current_damage_idx += 1

    func is_exhausted() -> bool:
        return current_damage_idx >= damage_queue.size()


class TransferSanction extends RefCounted:
    var origin_fire: FireSanction
    var hops: int = 0


var players: Array[Player] = []
var current_player_idx: int = 0
var direction: int = 1                       # 1 = horaire, -1 = anti-horaire
var deck: Deck = Deck.new()
var discard: DiscardPile = DiscardPile.new()

var required_suit: int = -1                  # Card.Suit ou -1
var active_fire: FireSanction = null
var active_transfer: TransferSanction = null
var replay_chain: int = 0                    # nb de 7 enchaînés
var must_replay: bool = false                # joueur courant doit rejouer post-7

var round_finished: bool = false
var game_finished: bool = false
var pending_skip: int = 0                    # nb de joueurs à sauter au prochain passage


func current_player() -> Player:
    return players[current_player_idx]


func next_player_idx(steps: int = 1) -> int:
    var n := players.size()
    var idx := current_player_idx
    var moved := 0
    while moved < steps:
        idx = (idx + direction + n) % n
        if not players[idx].is_eliminated:
            moved += 1
    return idx


func active_players_count() -> int:
    var c := 0
    for p in players:
        if not p.is_eliminated:
            c += 1
    return c


func top_reference() -> Card:
    return discard.top_reference()
