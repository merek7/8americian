extends Node
## Singleton de transmission entre menu et scène de jeu.

var pending_launch: Dictionary = {}  # ex: {"mode": "solo_vs_ai"}
