class_name RuleValidator extends RefCounted
## Validation des coups légaux. PURE FUNCTION : aucun effet de bord.
## Référence : SPEC.md §9 (RG-VALIDATION).

static func is_legal_move(card: Card, state: GameState) -> bool:
    if card == null:
        return false

    # Joker : toujours légal (RG-EFF-07).
    if card.is_joker():
        return true

    # Pendant une sanction de feu : seul un extincteur valide passe.
    if state.active_fire != null:
        return is_valid_fire_extinguisher(card, state.active_fire)

    # Pendant un transfer Joker : uniquement Joker (déjà couvert ci-dessus).
    if state.active_transfer != null:
        return false

    # Pendant chaîne de replay (must_replay) : règles spécifiques (RG-EFF-08-A).
    if state.must_replay:
        return is_legal_in_replay_chain(card, state)

    # Enseigne forcée par 8.
    if state.required_suit >= 0:
        return card.suit == state.required_suit or card.value == 8

    # Cas normal : même enseigne, même valeur, OU un 8 (universel).
    var top := state.top_reference()
    if top == null:
        return true
    return card.suit == top.suit or card.value == top.value or card.value == 8


static func is_valid_fire_extinguisher(card: Card, fire: GameState.FireSanction) -> bool:
    # Joker éteint toujours (transfert).
    if card.is_joker():
        return true

    var src := fire.source_card
    var src_is_spade: bool = src.suit == Card.Suit.SPADE

    # As♠ → uniquement As♠ ou Joker.
    if src.value == 1 and src_is_spade:
        return card.value == 1 and card.suit == Card.Suit.SPADE
    # As (non-pique) → As (toute enseigne) ou 8 (toute enseigne).
    if src.value == 1:
        return card.value == 1 or card.value == 8
    # 2♠ → uniquement 2♠ ou 8♠.
    if src.value == 2 and src_is_spade:
        return (card.value == 2 and card.suit == Card.Suit.SPADE) \
            or (card.value == 8 and card.suit == Card.Suit.SPADE)
    # 2 (non-pique) → 2 ou 8 (toute enseigne).
    if src.value == 2:
        return card.value == 2 or card.value == 8

    return false


static func is_legal_in_replay_chain(card: Card, state: GameState) -> bool:
    # Pendant un replay, on peut jouer :
    # - Un autre 7 (continue la chaîne).
    # - Une carte non-spéciale qui respecte enseigne/valeur du top_reference (carte finale).
    # - Une carte spéciale UNIQUEMENT si elle est légale ET termine la chaîne (la suite gérée par GameManager).
    if card.value == 7:
        return _matches_top(card, state)
    return _matches_top(card, state)


static func _matches_top(card: Card, state: GameState) -> bool:
    if state.required_suit >= 0:
        return card.suit == state.required_suit or card.value == 8
    var top := state.top_reference()
    if top == null:
        return true
    return card.suit == top.suit or card.value == top.value


static func legal_moves(player: Player, state: GameState) -> Array[Card]:
    var out: Array[Card] = []
    for c in player.hand:
        if is_legal_move(c, state):
            out.append(c)
    return out
