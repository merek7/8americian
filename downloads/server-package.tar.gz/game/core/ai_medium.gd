class_name AIMedium extends RefCounted
## IA medium : heuristique avec conscience de l'état (économise spéciales).

static func decide(player: Player, state: GameState) -> Dictionary:
    var legal: Array[Card] = RuleValidator.legal_moves(player, state)
    if legal.is_empty():
        return {"action": "draw"}

    # Filtre : ne pas finir avec un 7
    var safe: Array[Card] = []
    for c in legal:
        if not (player.hand_size() == 1 and c.value == 7):
            safe.append(c)
    if safe.is_empty(): safe = legal

    var best: Card = null
    var best_score: float = -INF
    for c in safe:
        var s := _score(c, player, state)
        if s > best_score:
            best_score = s
            best = c

    var result := {
        "action": "play",
        "card": best,
        "calling_carte": player.hand_size() == 2
    }
    if best.value == 8:
        result["chosen_suit"] = _dominant_suit(player.hand, best)
    return result


static func _score(c: Card, player: Player, state: GameState) -> float:
    var s := 0.0

    # Sous sanction : éteindre est prioritaire
    if state.active_fire != null:
        if c.value == 8 and c.suit == Card.Suit.SPADE: s += 200  # garde 8♠ pour cas pique
        elif c.value == 8: s += 150
        elif c.value == 2: s += 180
        elif c.value == 1: s += 160
        elif c.is_joker(): s += 120
        return s

    # Sous transfer Joker : seul Joker est légal de toute façon
    if state.active_transfer != null and c.is_joker():
        return 100.0

    # Hors sanction : économise les spéciales
    match c.value:
        0: s -= 30  # Joker : économiser pour défense
        1: s += 5   # As : faible valeur, ok
        2: s -= 15  # 2 : feu, économiser
        7: s += 10  # 7 : permet rejouer, utile
        8: s -= 20 if c.suit == Card.Suit.SPADE else -10  # 8 : économiser
        10: s += 0
        11: s += 12 if c.suit != Card.Suit.SPADE else 18  # Valet : skip = bonus
        _: s += float(c.points) * 0.5  # numériques : se débarrasser

    # Bonus de fin de partie : se débarrasser des grosses cartes
    if player.hand_size() <= 3:
        s += float(c.points) * 0.3

    return s


static func _dominant_suit(hand: Array[Card], excluding: Card) -> int:
    var counts := [0, 0, 0, 0]
    for c in hand:
        if c == excluding or c.is_joker(): continue
        if c.suit >= 0 and c.suit < 4:
            counts[c.suit] += 1
    var best := 0
    var best_count := -1
    for i in 4:
        if counts[i] > best_count:
            best_count = counts[i]
            best = i
    return best
