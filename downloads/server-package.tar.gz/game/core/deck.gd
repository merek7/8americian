class_name Deck extends RefCounted
## Pioche du jeu. Gère le mélange et la pioche de cartes.

var cards: Array[Card] = []


func build_standard(nb_decks: int) -> void:
    cards.clear()
    for i in nb_decks:
        for suit_idx in 4:
            var s: Card.Suit = suit_idx as Card.Suit
            for v in range(1, 14):
                cards.append(Card.create(v, s))
        # 2 jokers par deck
        cards.append(Card.create(0, Card.Suit.NONE))
        cards.append(Card.create(0, Card.Suit.NONE))


func shuffle_deck(rng: RandomNumberGenerator = null) -> void:
    if rng:
        # Mélange déterministe pour les tests
        for i in range(cards.size() - 1, 0, -1):
            var j := rng.randi_range(0, i)
            var tmp := cards[i]
            cards[i] = cards[j]
            cards[j] = tmp
    else:
        cards.shuffle()


func draw() -> Card:
    if cards.is_empty():
        return null
    return cards.pop_back()


func draw_n(n: int) -> Array[Card]:
    var out: Array[Card] = []
    for i in n:
        var c := draw()
        if c == null:
            break
        out.append(c)
    return out


func is_empty() -> bool:
    return cards.is_empty()


func size() -> int:
    return cards.size()


func refill_from(source_cards: Array[Card]) -> void:
    cards.append_array(source_cards)
    shuffle_deck()
