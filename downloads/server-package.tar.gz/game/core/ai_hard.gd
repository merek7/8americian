class_name AIHard extends RefCounted
## IA hard : Medium + lookahead 1 coup (simule l'effet sur la main et le top de défausse).

static func decide(player: Player, state: GameState) -> Dictionary:
    var legal: Array[Card] = RuleValidator.legal_moves(player, state)
    if legal.is_empty():
        return {"action": "draw"}

    var safe: Array[Card] = []
    for c in legal:
        if not (player.hand_size() == 1 and c.value == 7):
            safe.append(c)
    if safe.is_empty(): safe = legal

    var best: Card = null
    var best_score: float = -INF
    for c in safe:
        var s := AIMedium._score(c, player, state)
        s += _lookahead_bonus(c, player)
        if s > best_score:
            best_score = s
            best = c

    var result := {
        "action": "play",
        "card": best,
        "calling_carte": player.hand_size() == 2
    }
    if best.value == 8:
        result["chosen_suit"] = _best_suit_after(player.hand, best)
    return result


static func _lookahead_bonus(c: Card, player: Player) -> float:
    # Bonus si jouer cette carte laisse une main "saine" (équilibre des enseignes).
    var remaining: Array[Card] = []
    for h in player.hand:
        if h != c: remaining.append(h)
    if remaining.is_empty():
        return 100.0  # gagne la manche !

    # Compte les enseignes restantes
    var counts := [0, 0, 0, 0]
    var jokers := 0
    for h in remaining:
        if h.is_joker(): jokers += 1
        elif h.suit >= 0 and h.suit < 4:
            counts[h.suit] += 1

    # Variance des enseignes : moins de variance = main équilibrée = mieux
    var max_c := 0
    var min_c := 9999
    for v in counts:
        max_c = maxi(max_c, v)
        min_c = mini(min_c, v)
    var balance: float = float(min_c) / float(max(1, max_c))  # 0..1, plus haut = plus équilibré
    var bonus: float = balance * 8.0
    bonus += jokers * 4.0                          # Joker en réserve = sécurité
    bonus -= float(remaining.size()) * 0.5         # main plus petite = mieux
    return bonus


static func _best_suit_after(hand: Array[Card], excluding: Card) -> int:
    # Choix d'enseigne (8) basé sur celle où on a le plus de cartes
    return AIMedium._dominant_suit(hand, excluding)
