extends Node
## Orchestre une série de parties liées (modes A/B/C). Singleton.

signal tournament_started(mode: String, total_games: int)
signal tournament_game_recorded(games_played: int, total_games: int, leader_name: String, leader_wins: int)
signal tournament_finished(champion_name: String, player_won: bool, mode: String)

var active: bool = false
var mode: String = ""  # "career" | "multi_ai" | "best_of_n"
var total_games: int = 0
var games_played: int = 0
var wins: Dictionary = {}  # name -> int
var difficulty_sequence: Array[String] = []
var ai_count: int = 1
var ai_mix: Array[String] = []
var score_target: int = 50
var cards_dealt: int = 5


func start_career(nb_games: int) -> void:
    _reset()
    active = true
    mode = "career"
    total_games = nb_games
    difficulty_sequence = _career_progression(nb_games)
    ai_count = 1
    tournament_started.emit(mode, total_games)


func start_best_of_n(difficulty: String, nb_games: int) -> void:
    _reset()
    active = true
    mode = "best_of_n"
    total_games = nb_games
    var seq: Array[String] = []
    for _i in nb_games: seq.append(difficulty)
    difficulty_sequence = seq
    ai_count = 1
    tournament_started.emit(mode, total_games)


func start_multi_ai(nb_ai: int, nb_games: int) -> void:
    _reset()
    active = true
    mode = "multi_ai"
    total_games = nb_games
    ai_count = nb_ai
    ai_mix = _ai_mix_for(nb_ai)
    var seq: Array[String] = []
    for _i in nb_games: seq.append("mixed")
    difficulty_sequence = seq
    tournament_started.emit(mode, total_games)


func reset() -> void:
    _reset()


func record_game_winner(winner_name: String) -> void:
    if not active: return
    games_played += 1
    wins[winner_name] = int(wins.get(winner_name, 0)) + 1
    var leader: String = _leader_name()
    var leader_wins: int = int(wins.get(leader, 0))
    tournament_game_recorded.emit(games_played, total_games, leader, leader_wins)
    if games_played >= total_games or _player_has_majority():
        active = false
        var champ: String = _leader_name()
        var pseudo: String = Profile.pseudo if has_node("/root/Profile") else ""
        var player_won: bool = champ == pseudo
        tournament_finished.emit(champ, player_won, mode)
        if has_node("/root/Profile"):
            Profile.record_tournament(player_won)


func next_game_config() -> Dictionary:
    if not active: return {}
    var idx: int = mini(games_played, difficulty_sequence.size() - 1)
    var diff: String = difficulty_sequence[idx]
    if mode == "multi_ai":
        diff = "medium"  # représentatif du mix pour les stats
    var nb_players: int = ai_count + 1
    var cfg := {
        "nb_decks": maxi(2, int(ceil(nb_players / 2.0))),
        "nb_players": nb_players,
        "cards_dealt": cards_dealt,
        "score_target": score_target,
        "mode": "tournament",
        "ai_difficulty": diff,
        "_tournament_mode": mode,
    }
    return cfg


func ai_names() -> Array[String]:
    # Pour multi_ai : noms étiquetés avec leur difficulté
    var out: Array[String] = []
    if mode == "multi_ai":
        var label_for := {"basic": "Basique", "medium": "Medium", "hard": "Hard"}
        for i in ai_count:
            var d: String = ai_mix[i] if i < ai_mix.size() else "basic"
            out.append("IA %s %d" % [label_for.get(d, "?"), i + 1])
    elif mode == "career":
        var idx: int = mini(games_played, difficulty_sequence.size() - 1)
        out.append("IA %s" % difficulty_sequence[idx].capitalize())
    else:  # best_of_n
        var idx2: int = mini(games_played, difficulty_sequence.size() - 1)
        out.append("IA %s" % difficulty_sequence[idx2].capitalize())
    return out


func ai_difficulty_for_seat(seat_index: int) -> String:
    # Renvoie la difficulté d'une IA donnée (0-indexed parmi les IA, pas les joueurs)
    if mode == "multi_ai" and seat_index < ai_mix.size():
        return ai_mix[seat_index]
    var idx: int = mini(games_played, difficulty_sequence.size() - 1)
    return difficulty_sequence[idx] if idx >= 0 and idx < difficulty_sequence.size() else "basic"


func progress_text() -> String:
    var pseudo: String = Profile.pseudo if has_node("/root/Profile") else "Joueur"
    var p_wins: int = int(wins.get(pseudo, 0))
    return "Manche %d / %d  •  Tes victoires : %d" % [games_played, total_games, p_wins]


func _reset() -> void:
    active = false
    mode = ""
    total_games = 0
    games_played = 0
    wins.clear()
    difficulty_sequence.clear()
    ai_mix.clear()
    ai_count = 1


func _career_progression(n: int) -> Array[String]:
    match n:
        3: return ["basic", "medium", "hard"]
        5: return ["basic", "basic", "medium", "medium", "hard"]
        7: return ["basic", "basic", "medium", "medium", "hard", "hard", "hard"]
        _: return ["basic"]


func _ai_mix_for(nb: int) -> Array[String]:
    var diffs := ["basic", "medium", "hard"]
    var out: Array[String] = []
    for i in nb:
        out.append(diffs[i % 3])
    return out


func _leader_name() -> String:
    var best: int = -1
    var n: String = ""
    for k in wins.keys():
        var w: int = int(wins[k])
        if w > best:
            best = w
            n = k
    return n


func _player_has_majority() -> bool:
    var needed: int = floori(total_games / 2.0) + 1
    for k in wins.keys():
        if int(wins[k]) >= needed:
            return true
    return false
