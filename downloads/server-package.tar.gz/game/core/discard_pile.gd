class_name DiscardPile extends RefCounted
## Défausse. Le top de la pile est utilisé comme référence pour les coups légaux,
## sauf quand un Joker est joué (RG-EFF-07 H-02 : Joker glisse sous la pile).

var cards: Array[Card] = []
# top_reference_card peut différer du dernier élément si Joker actif (cf. RG-EFF-07).
var _top_reference: Card = null


func push(card: Card, update_reference: bool = true) -> void:
    cards.append(card)
    if update_reference:
        _top_reference = card


func push_under(card: Card) -> void:
    # Joker glisseur : posé sous la pile, top_reference inchangé.
    cards.insert(max(0, cards.size() - 1), card)


func top() -> Card:
    if cards.is_empty():
        return null
    return cards.back()


func top_reference() -> Card:
    return _top_reference


func set_top_reference(card: Card) -> void:
    _top_reference = card


func size() -> int:
    return cards.size()


func take_all_except_top() -> Array[Card]:
    if cards.size() <= 1:
        return []
    var preserved: Card = cards.back()
    var rest: Array[Card] = []
    for i in range(cards.size() - 1):
        rest.append(cards[i])
    cards = [preserved]
    return rest


func reset() -> void:
    cards.clear()
    _top_reference = null
