class_name EffectManager extends RefCounted
## Résolution des effets de cartes. Dispatcher Strategy.

func resolve(card: Card, state: GameState, context: Dictionary = {}) -> EffectBase.EffectResult:
    match card.effect_type:
        Card.EffectType.FIRE:
            return FireEffect.new().apply(card, state)
        Card.EffectType.BLOCK:
            var e := BlockEffect.new()
            e.set_chosen_suit(context.get("chosen_suit", -1))
            return e.apply(card, state)
        Card.EffectType.TRANSFER:
            return TransferEffect.new().apply(card, state)
        Card.EffectType.REPLAY:
            return ReplayEffect.new().apply(card, state)
        Card.EffectType.SKIP:
            return SkipEffect.new().apply(card, state)
        Card.EffectType.REVERSE:
            return ReverseEffect.new().apply(card, state)
        _:
            var r := EffectBase.EffectResult.new()
            r.message = "Aucun effet"
            return r
