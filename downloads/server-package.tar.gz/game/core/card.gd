class_name Card extends Resource
## Représente une carte du jeu. Resource = sérialisable, hot-reload friendly.

enum Suit { HEART, DIAMOND, CLUB, SPADE, NONE }
enum EffectType { NONE, FIRE, BLOCK, TRANSFER, REPLAY, SKIP, REVERSE }

@export var value: int = 0          # 0=Joker, 1=As, 2-10, 11=Valet, 12=Dame, 13=Roi
@export var suit: Suit = Suit.NONE
@export var effect_type: EffectType = EffectType.NONE
@export var points: int = 0


static func create(p_value: int, p_suit: Suit) -> Card:
    var c := Card.new()
    c.value = p_value
    c.suit = p_suit
    c.effect_type = _resolve_effect(p_value)
    c.points = _resolve_points(p_value, p_suit)
    return c


static func _resolve_effect(v: int) -> EffectType:
    match v:
        0: return EffectType.TRANSFER     # Joker
        1, 2: return EffectType.FIRE       # As, 2
        7: return EffectType.REPLAY
        8: return EffectType.BLOCK
        10: return EffectType.REVERSE
        11: return EffectType.SKIP         # Valet
        _: return EffectType.NONE


static func _resolve_points(v: int, s: Suit) -> int:
    if v == 0: return 50                   # Joker
    if v == 2 and s == Suit.SPADE: return 4
    if v == 8 and s == Suit.SPADE: return 64
    if v == 8: return 32
    if v == 11 and s == Suit.SPADE: return 22
    if v == 11: return 11
    if v == 12 or v == 13: return 1        # Dame, Roi
    if v == 1: return 1                    # As
    return v                               # 3..10


func is_joker() -> bool:
    return value == 0


func is_spade_special() -> bool:
    return suit == Suit.SPADE and (value == 1 or value == 2 or value == 8 or value == 11)


func to_string_short() -> String:
    var v_str := str(value)
    match value:
        0: v_str = "JK"
        1: v_str = "A"
        11: v_str = "J"
        12: v_str = "Q"
        13: v_str = "K"
    var s_str: String = ["H", "D", "C", "S", "-"][suit]
    return "%s%s" % [v_str, s_str]
