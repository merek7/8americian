extends Node
## Effets sonores générés procéduralement (pas d'asset externe).
## Sons courts type "blip", "click", "rumble" via AudioStreamWAV PCM16.

const SAMPLE_RATE := 22050
const VOLUME_DB := -6.0

var streams: Dictionary = {}
var players: Array[AudioStreamPlayer] = []
var _next_player := 0

const POOL_SIZE := 8


func _ready() -> void:
    # Pool de players réutilisables (permet des sons concurrents)
    for i in POOL_SIZE:
        var p := AudioStreamPlayer.new()
        p.bus = "Master"
        p.volume_db = VOLUME_DB
        add_child(p)
        players.append(p)

    streams["card_play"] = _make_chirp(800.0, 1200.0, 0.08, 0.6)
    streams["card_draw"] = _make_chirp(600.0, 400.0, 0.10, 0.55)
    streams["fire"] = _make_noise_blast(0.30, 0.7)
    streams["carte"] = _make_bell(880.0, 0.35, 0.5)
    streams["click"] = _make_chirp(1400.0, 1400.0, 0.04, 0.4)
    streams["win"] = _make_arpeggio([523.25, 659.25, 783.99, 1046.5], 0.12, 0.6)
    streams["bad"] = _make_chirp(300.0, 200.0, 0.18, 0.55)


func play(name: StringName) -> void:
    if not streams.has(name):
        return
    var p := players[_next_player]
    _next_player = (_next_player + 1) % POOL_SIZE
    p.stream = streams[name]
    p.play()


# ── Générateurs ────────────────────────────────────────────────────────────────

func _make_chirp(freq_start: float, freq_end: float, duration: float, vol: float) -> AudioStreamWAV:
    var n: int = int(SAMPLE_RATE * duration)
    var data := PackedByteArray()
    data.resize(n * 2)
    for i in n:
        var t: float = float(i) / SAMPLE_RATE
        var f: float = lerp(freq_start, freq_end, t / duration)
        var phase: float = 2.0 * PI * f * t
        var env: float = _envelope(t, duration, 0.005, 0.05)
        var sample: float = sin(phase) * env * vol
        _write_sample(data, i, sample)
    return _wrap(data)


func _make_bell(freq: float, duration: float, vol: float) -> AudioStreamWAV:
    var n: int = int(SAMPLE_RATE * duration)
    var data := PackedByteArray()
    data.resize(n * 2)
    for i in n:
        var t: float = float(i) / SAMPLE_RATE
        var env: float = exp(-t * 8.0)
        var s: float = sin(2.0 * PI * freq * t) * 0.6
        s += sin(2.0 * PI * freq * 2.0 * t) * 0.3 * exp(-t * 12.0)
        s += sin(2.0 * PI * freq * 3.0 * t) * 0.15 * exp(-t * 16.0)
        _write_sample(data, i, s * env * vol)
    return _wrap(data)


func _make_noise_blast(duration: float, vol: float) -> AudioStreamWAV:
    var n: int = int(SAMPLE_RATE * duration)
    var data := PackedByteArray()
    data.resize(n * 2)
    var rng := RandomNumberGenerator.new()
    var prev: float = 0.0
    for i in n:
        var t: float = float(i) / SAMPLE_RATE
        var noise: float = rng.randf_range(-1.0, 1.0)
        # Lowpass simple → rumble grave
        var smoothed: float = lerp(prev, noise, 0.15)
        prev = smoothed
        var env: float = exp(-t * 4.0)
        _write_sample(data, i, smoothed * env * vol)
    return _wrap(data)


func _make_arpeggio(freqs: Array, note_dur: float, vol: float) -> AudioStreamWAV:
    var total: float = note_dur * freqs.size()
    var n: int = int(SAMPLE_RATE * total)
    var data := PackedByteArray()
    data.resize(n * 2)
    for i in n:
        var t: float = float(i) / SAMPLE_RATE
        var note_idx: int = mini(int(t / note_dur), freqs.size() - 1)
        var note_t: float = t - note_idx * note_dur
        var f: float = freqs[note_idx]
        var env: float = _envelope(note_t, note_dur, 0.005, 0.04)
        var s: float = sin(2.0 * PI * f * note_t) * env * vol
        _write_sample(data, i, s)
    return _wrap(data)


func _envelope(t: float, dur: float, attack: float, release: float) -> float:
    if t < attack:
        return t / attack
    if t > dur - release:
        return max(0.0, (dur - t) / release)
    return 1.0


func _write_sample(data: PackedByteArray, idx: int, sample: float) -> void:
    var v: int = clampi(int(sample * 32767.0), -32768, 32767)
    data.encode_s16(idx * 2, v)


func _wrap(data: PackedByteArray) -> AudioStreamWAV:
    var s := AudioStreamWAV.new()
    s.format = AudioStreamWAV.FORMAT_16_BITS
    s.mix_rate = SAMPLE_RATE
    s.stereo = false
    s.data = data
    return s
