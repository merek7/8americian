extends Node
## Orchestrateur principal — Singleton (autoload).
## Référence : SPEC.md §3 (state machine) et §4 (flux de jeu).

signal game_started(config: Dictionary)
signal round_started(round_num: int)
signal round_ended(scores: Dictionary)
signal game_over(winner_id: int)
signal player_changed(player_id: int)
signal card_played(card: Card, player_id: int)
signal card_drawn(player_id: int, count: int)
signal effect_triggered(effect_name: String, payload: Dictionary)
signal carte_announce_required(player_id: int)
signal carte_missed_penalty(player_id: int)
signal illegal_move(player_id: int, reason: String)
signal suit_choice_required(player_id: int)
signal fire_landed(player_id: int, damage: int)

const PENALTY_CARTE_MISS := 4
const PENALTY_REPLAY_CHEAT := 4
const PENALTY_FINISH_WITH_7 := 1

var state: GameState = null
var turn_manager: TurnManager = null
var effect_manager: EffectManager = null
var config: Dictionary = {
    "nb_decks": 2,
    "nb_players": 2,
    "cards_dealt": 5,
    "score_target": 100,
    "mode": "local_multi",
    "ai_difficulty": "basic"
}
var round_num: int = 0


func start_game(p_config: Dictionary, player_names: Array = []) -> void:
    config = p_config.duplicate()
    state = GameState.new()
    turn_manager = TurnManager.new()
    effect_manager = EffectManager.new()
    round_num = 0

    var n: int = config["nb_players"]
    var per_ai_diffs: Array = config.get("per_ai_difficulty", [])
    for i in n:
        var pname: String = player_names[i] if i < player_names.size() else "Joueur %d" % (i + 1)
        var is_ai: bool = ((config["mode"] == "solo_vs_ai" or config["mode"] == "tournament") and i > 0)
        var p := Player.create(i, pname, is_ai)
        if is_ai and (i - 1) < per_ai_diffs.size():
            p.ai_difficulty = per_ai_diffs[i - 1]
        state.players.append(p)

    game_started.emit(config)
    _start_round()


func _start_round() -> void:
    round_num += 1

    # Reset état de manche
    for p in state.players:
        p.hand.clear()
        p.has_called_carte = false
    state.deck = Deck.new()
    state.discard = DiscardPile.new()
    state.required_suit = -1
    state.active_fire = null
    state.active_transfer = null
    state.replay_chain = 0
    state.must_replay = false
    state.pending_skip = 0
    state.direction = 1
    state.round_finished = false

    state.deck.build_standard(config["nb_decks"])
    state.deck.shuffle_deck()

    # Distribution
    for p in state.players:
        if not p.is_eliminated:
            p.add_cards(state.deck.draw_n(config["cards_dealt"]))

    # Première carte sur la défausse : tirée au hasard.
    # Si Joker → on retire et on retire à nouveau (pas de référence valide possible).
    var first := state.deck.draw()
    while first != null and first.is_joker():
        state.deck.cards.push_front(first)
        state.deck.shuffle_deck()
        first = state.deck.draw()
    if first != null:
        state.discard.push(first)
        # Effet de la 1ère carte : on n'applique PAS l'effet (le 1er joueur joue normalement).
        # La carte sert juste de référence pour la validation enseigne/valeur.

    # Premier joueur actif
    state.current_player_idx = 0
    while state.players[state.current_player_idx].is_eliminated:
        state.current_player_idx = (state.current_player_idx + 1) % state.players.size()

    round_started.emit(round_num)
    player_changed.emit(state.current_player().id)
    _broadcast()
    _maybe_play_ai()


# ─── API publique pour l'UI ────────────────────────────────────────────────────

func player_plays_card(player_id: int, card: Card, context: Dictionary = {}) -> bool:
    if state.current_player().id != player_id:
        illegal_move.emit(player_id, "Ce n'est pas votre tour")
        return false

    if not RuleValidator.is_legal_move(card, state):
        illegal_move.emit(player_id, "Coup illégal")
        return false

    var player := state.current_player()

    # RG-EFF-08-A : triche de chaîne replay (carte spéciale au milieu)
    if state.must_replay and state.replay_chain >= 1 and card.value != 7:
        if _is_special(card):
            # Vérifier si c'est la "fin" : autorisé si le joueur n'a plus de 7 dans sa main
            var has_more_7 := false
            for c in player.hand:
                if c != card and c.value == 7:
                    has_more_7 = true; break
            if has_more_7:
                _apply_penalty(player, PENALTY_REPLAY_CHEAT)
                illegal_move.emit(player_id, "Triche : sanction au milieu d'une chaîne de 7")
                return false

    # Annonce "Carte" — vérifier le déclaratif AVANT de jouer (l'UI passe context.calling_carte)
    if player.hand_size() == 2:
        player.has_called_carte = bool(context.get("calling_carte", false))

    player.remove_card(card)

    # Pose sur défausse selon glisseur
    if card.is_joker() and (state.active_fire != null or state.active_transfer != null or state.discard.size() > 0):
        state.discard.push_under(card)
    else:
        state.discard.push(card)

    card_played.emit(card, player_id)

    # Reset enseigne forcée si on a joué autre chose qu'un 8
    if card.value != 8:
        state.required_suit = -1

    # Résoudre l'effet
    var result := effect_manager.resolve(card, state, context)
    effect_triggered.emit(_effect_name(card), {"message": result.message})

    # Cas final : main vide
    if player.is_empty():
        if card.value == 7:
            # RG-EFF-08-B : pioche 1, le tour continue
            _draw_into_player(player, 1)
            return true
        else:
            _end_round(player_id)
            return true

    # RG-EFF-08-C : "Carte" annoncé + 7 = pioche 1
    if card.value == 7 and player.hand_size() == 1 and player.has_called_carte:
        _draw_into_player(player, PENALTY_FINISH_WITH_7)

    # Pénalité Carte oubliée (rétroactive : si 1 carte en main, jamais annoncé)
    if player.hand_size() == 1 and not player.has_called_carte:
        _apply_penalty(player, PENALTY_CARTE_MISS)
        carte_missed_penalty.emit(player_id)
        player.has_called_carte = false

    # Avance ou rejoue
    if state.must_replay:
        state.must_replay = false
        var legal := RuleValidator.legal_moves(player, state)
        if legal.is_empty():
            _draw_into_player(player, 1)
            state.replay_chain = 0
            _advance_turn()
        else:
            # Le joueur courant rejoue : notifier l'UI et relancer l'IA si besoin
            player_changed.emit(player.id)
            _maybe_play_ai()
            return true
    else:
        state.replay_chain = 0
        _advance_turn()

    return true


func player_draws(player_id: int) -> bool:
    if state.current_player().id != player_id:
        return false
    var player := state.current_player()

    # Si feu actif sur ce joueur : prendre la pioche du feu
    if state.active_fire != null:
        var dmg: int = state.active_fire.current_damage()
        _draw_into_player(player, dmg)
        fire_landed.emit(player_id, dmg)
        state.active_fire.advance()
        if state.active_fire.is_exhausted():
            state.active_fire = null
        # Le feu continue vers le suivant si pas exhausted
    elif state.active_transfer != null:
        # Le joueur n'a pas de Joker : il doit prendre la sanction d'origine
        var dmg2: int = state.active_transfer.origin_fire.current_damage()
        _draw_into_player(player, dmg2)
        state.active_transfer = null
    else:
        _draw_into_player(player, 1)

    _advance_turn()
    return true


# ─── Internes ──────────────────────────────────────────────────────────────────

func _draw_into_player(player: Player, n: int) -> void:
    var drawn: Array[Card] = []
    for i in n:
        if state.deck.is_empty():
            _refill_deck_from_discard()
        var c := state.deck.draw()
        if c == null:
            break
        drawn.append(c)
    player.add_cards(drawn)
    card_drawn.emit(player.id, drawn.size())


func _refill_deck_from_discard() -> void:
    var recycled := state.discard.take_all_except_top()
    if recycled.is_empty():
        return
    state.deck.refill_from(recycled)


func _apply_penalty(player: Player, n: int) -> void:
    _draw_into_player(player, n)


func _advance_turn() -> void:
    turn_manager.advance(state)
    player_changed.emit(state.current_player().id)
    _broadcast()
    _maybe_play_ai()


func _broadcast() -> void:
    if NetworkManager and NetworkManager.is_online and NetworkManager.is_host:
        NetworkManager.broadcast_state()


func _maybe_play_ai() -> void:
    if state == null or state.round_finished or state.game_finished:
        return
    var cur: Player = state.current_player()
    if not cur.is_ai:
        return
    # Délai léger pour que l'UI puisse refléter le tour avant que l'IA ne joue
    var loop := Engine.get_main_loop()
    if loop and loop is SceneTree:
        var timer: SceneTreeTimer = (loop as SceneTree).create_timer(0.4)
        timer.timeout.connect(_run_ai_action.bind(cur.id))
    else:
        _run_ai_action(cur.id)


func _run_ai_action(player_id: int) -> void:
    if state == null or state.current_player().id != player_id:
        return
    var cur: Player = state.current_player()
    var difficulty: String = cur.ai_difficulty if cur.ai_difficulty != "" else config.get("ai_difficulty", "basic")
    var decision: Dictionary
    match difficulty:
        "medium": decision = AIMedium.decide(cur, state)
        "hard": decision = AIHard.decide(cur, state)
        _: decision = AIBasic.decide(cur, state)
    if decision["action"] == "draw":
        player_draws(cur.id)
    else:
        var ctx: Dictionary = {
            "calling_carte": decision.get("calling_carte", false)
        }
        if decision.has("chosen_suit"):
            ctx["chosen_suit"] = decision["chosen_suit"]
        player_plays_card(cur.id, decision["card"], ctx)


func _end_round(winner_id: int) -> void:
    state.round_finished = true
    state.active_fire = null
    state.active_transfer = null

    var scores := {}
    for p in state.players:
        if p.id != winner_id:
            var pts := p.hand_points()
            p.score += pts
            scores[p.id] = p.score
            if p.score >= config["score_target"]:
                p.is_eliminated = true
    scores[winner_id] = state.players[winner_id].score
    round_ended.emit(scores)

    if state.active_players_count() <= 1:
        var winner := -1
        for p in state.players:
            if not p.is_eliminated:
                winner = p.id; break
        state.game_finished = true
        game_over.emit(winner)
    # Sinon : on attend que l'UI appelle continue_to_next_round() (popup sablier).


func continue_to_next_round() -> void:
    if state == null or state.game_finished: return
    if not state.round_finished: return
    _start_round()


func _is_special(card: Card) -> bool:
    return card.effect_type != Card.EffectType.NONE and card.value != 7


func _effect_name(card: Card) -> String:
    match card.effect_type:
        Card.EffectType.FIRE: return "FIRE"
        Card.EffectType.BLOCK: return "BLOCK"
        Card.EffectType.TRANSFER: return "TRANSFER"
        Card.EffectType.REPLAY: return "REPLAY"
        Card.EffectType.SKIP: return "SKIP"
        Card.EffectType.REVERSE: return "REVERSE"
        _: return "NONE"
