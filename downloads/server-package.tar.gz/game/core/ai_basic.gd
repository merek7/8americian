class_name AIBasic extends RefCounted
## IA niveau basique : heuristique simple.
## Stratégie :
##   1. Si sanction subie : éteindre si possible, sinon Joker, sinon piocher.
##   2. Sinon : préfère jouer une carte spéciale (sauf 7 si dernière).
##   3. Choisit l'enseigne dominante en main quand il pose un 8.

static func decide(player: Player, state: GameState) -> Dictionary:
    ## Renvoie {"action": "play"|"draw"|"call_carte", "card": Card, "chosen_suit": int, "calling_carte": bool}
    var legal: Array[Card] = RuleValidator.legal_moves(player, state)

    if legal.is_empty():
        return {"action": "draw"}

    # Filtre : ne pas finir avec un 7
    var safe_legal: Array[Card] = []
    for c in legal:
        if not (player.hand_size() == 1 and c.value == 7):
            safe_legal.append(c)
    if safe_legal.is_empty():
        safe_legal = legal

    # Priorise spéciales (sauf 7) si plusieurs cartes en main, sinon valeur la plus haute
    safe_legal.sort_custom(_score_priority)
    var chosen: Card = safe_legal[0]

    var result := {
        "action": "play",
        "card": chosen,
        "calling_carte": player.hand_size() == 2
    }
    if chosen.value == 8:
        result["chosen_suit"] = _dominant_suit(player.hand, chosen)
    return result


static func _score_priority(a: Card, b: Card) -> bool:
    # true si a doit passer avant b
    return _priority_value(a) > _priority_value(b)


static func _priority_value(c: Card) -> int:
    # Plus haut = joué en priorité
    if c.is_joker(): return 5
    match c.effect_type:
        Card.EffectType.FIRE: return 80
        Card.EffectType.BLOCK: return 90
        Card.EffectType.SKIP: return 70
        Card.EffectType.REVERSE: return 60
        Card.EffectType.REPLAY: return 30  # 7 : peu prioritaire
        _: return c.points


static func _dominant_suit(hand: Array[Card], excluding: Card) -> int:
    var counts := [0, 0, 0, 0]
    for c in hand:
        if c == excluding or c.is_joker():
            continue
        if c.suit >= 0 and c.suit < 4:
            counts[c.suit] += 1
    var best := 0
    var best_count := -1
    for i in 4:
        if counts[i] > best_count:
            best_count = counts[i]
            best = i
    return best
